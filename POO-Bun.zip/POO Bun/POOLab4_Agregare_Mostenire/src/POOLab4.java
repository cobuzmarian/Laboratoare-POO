
public class POOLab4 {

	public static void main(String args[])
	{
		Profesor prof = new Profesor("Ghiu","Matematica");
		Student stud = new Student("Claudiu",1);
		Student stud2 = new Student("Claudiu",2);
		
		System.out.println("La materia "+prof.materie+
				",predata de profesorul "+prof.nume +
				" studentul "+stud.nume +" a obtinut nota " +stud.nota);
		
		System.out.println(prof.toString());
		System.out.println(stud.toString());
		
		System.out.println("Stud equals stud2 "+ stud.equals(stud2));
		

		Persoana[] vect = new Persoana[20];
		vect[0] = prof;
		vect[1] = stud;
		vect[2] = stud2;
		
		System.out.println("---------------------------------------");
		System.out.println("Upcasting");
		
		for(int i=0;i<2;i++)
			System.out.println(vect[i].toString());
		
		System.out.println("---------------------------------------");
		System.out.println("Downcasting");
		
		for(int i=0;i<2;i++)
		{
			if(vect[i] instanceof Profesor)
				System.out.println(((Profesor) vect[i]).preda());
			else
				System.out.println(((Student) vect[i]).invata());
			
		}
		
	}
	
}
