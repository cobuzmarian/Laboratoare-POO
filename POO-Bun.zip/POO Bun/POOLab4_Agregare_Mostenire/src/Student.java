
public class Student extends Persoana{
	
	public int nota;

	public Student(String nume,int nota)
	{
		this.nota = nota;
		super.nume = nume;
	}
	
	public Student() {};

	public String toString()
	{
		return "Student: "+super.toString()+", "+this.nota;
	}
	
	/**
	 * Verifica daca doi studenti au acelasi nume
	 * @param unu
	 * @param doi
	 * @return
	 */
	public boolean equals(Student doi)
	{
		return super.nume.equals(doi.nume);

	}
	
	public String invata()
	{
		return "Elevul invata!";
	}
}
