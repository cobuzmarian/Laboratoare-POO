
public class Profesor extends Persoana{
	
	public String materie;
	
	public Profesor(String nume, String materie )
	{
		this.materie = materie;
		super.nume = nume;
	}
	
	public Profesor() { }

	
	public String toString()
	{
		return "Profesor: "+super.toString()+", "+this.materie;
	}
	
	public String preda()
	{
		return "Profesorul preda!";
	}
	
}
