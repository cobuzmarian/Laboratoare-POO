
public class Persoana {

	public String nume;
	
	public Persoana(String nume)
	{
		this.nume = nume;
	}
	
	public Persoana() { }

	public String toString()
	{
		return this.nume;
	}
}
