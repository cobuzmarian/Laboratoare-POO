package poo.Exceptions;

public class TooBoredException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9197228731526228803L;
	
	String message;
	public TooBoredException(String message)
	{
		this.message = message;
	}
	
	public String getMessage(){
		return message;
	}

}
