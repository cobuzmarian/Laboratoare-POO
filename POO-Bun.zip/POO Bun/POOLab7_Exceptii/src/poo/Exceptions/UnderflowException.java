package poo.Exceptions;

public class UnderflowException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2086947958258348084L;

	public UnderflowException(String message){
		super(message);
	}
	
}
