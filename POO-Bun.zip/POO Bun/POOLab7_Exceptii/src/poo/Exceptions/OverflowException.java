package poo.Exceptions;

public class OverflowException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -751474947602981550L;

	public OverflowException(String message){
		super(message);
	}

}
