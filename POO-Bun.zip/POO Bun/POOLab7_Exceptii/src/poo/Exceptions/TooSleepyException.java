package poo.Exceptions;

public class TooSleepyException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1139869221553122658L;
	String message;
	public TooSleepyException(String message)
	{
		this.message = message;
	}
	
	public String getMessage(){
		return message;
	}
}
