package poo.Exceptions;

public class TooHappyException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8967763414504138902L;

	public TooHappyException(String message)
	{
		super(message);
	}
	
}
