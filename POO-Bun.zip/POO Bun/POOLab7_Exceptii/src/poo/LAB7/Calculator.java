package poo.LAB7;

import java.util.ArrayList;
import java.util.Iterator;
import poo.Exceptions.OverflowException;
import poo.Exceptions.UnderflowException;;

public class Calculator {

	public Calculator()
	{
		
	}
	
	public int add(int x,int y)
	{
		if(x > 0 && y > 0 && x+y <0)
			throw new OverflowException("Suma este prea mare!");
		
		if(x < 0 && y< 0 && x+y > 0)
			throw new UnderflowException("Suma este prea mica!");
		
		return x+y;
	}
	
	public int divide(int x,int y)
	{
		return x/y;
	}
	
	public int average(ArrayList average)
	{
		int suma = 0;
		Iterator it = average.iterator();
		
		while(it.hasNext())
		{
			suma = add(suma,Integer.parseInt(it.next().toString()));
		}
		
		return divide(suma,average.size());
	}
}
