package poo.LAB7;

import java.util.ArrayList;
import java.util.Random;

import poo.Exceptions.OverflowException;
import poo.Exceptions.TooBoredException;
import poo.Exceptions.TooHappyException;
import poo.Exceptions.TooSleepyException;

public class Main {

	public static void main(String args[])
	{
		
		try{
			Random r = new Random();
			System.out.println(howDoYouFeel(r.nextInt(100),r.nextInt(100),r.nextInt(100)));
		}catch(TooHappyException ex)
		{
			System.out.println(ex.getMessage());
		}catch(TooBoredException ex)
		{
			System.out.println(ex.getMessage());
		}catch(TooSleepyException ex)
		{
			System.out.println(ex.getMessage());
		}finally{
			System.out.println("But you're cool anyway!");
		}
		
		try{
			memoryCheck();
		}catch(OutOfMemoryError ex)
		{
			System.out.println(ex.getMessage());
		}
		
		try{
			overflowCheck();
		}catch (StackOverflowError ex)
		{
			System.out.println(ex.getMessage());
		}
		
		Calculator test = new Calculator();
		ArrayList<Integer> average = new ArrayList<Integer>();
		
		average.add(1);
		average.add(20);
		average.add(60);
		
		System.out.println(test.average(average));
		
			testFinally();

		
	}
	
	@SuppressWarnings("unused")
	public static void memoryCheck(){
		int[] v = new int[1000000000];
	}
	
	@SuppressWarnings("finally")
	public static int testFinally() {
		
		try{
			System.out.println("--------------------------");
			return 20 / 0;
		}catch(OverflowException ex)
		{
			System.out.println(ex);
		}finally{
			System.out.println("ceva");
			return 0;
		}
				
	}
	
	public static void overflowCheck() {
		overflowCheck();
	}
	
	public static String howDoYouFeel(int happynessLevel,int boredomLevel,int sleepynessLevel) throws TooHappyException, TooBoredException, TooSleepyException
	{
		
			if(happynessLevel > 70)
				throw new TooHappyException("You're too damn happy !");
		
			if(boredomLevel > 40)
				throw new TooBoredException("You are too bored!");
			
			if(sleepynessLevel > 10)
				throw new TooSleepyException("You are too sleepy!");
			
			return "You are feeling GREAT !";
	}
}
