package poo.myduck;

import java.util.ArrayList;

public class Stack implements Container{

	ArrayList<Task> list;
	int pos = 0;
	int count = 0; // counting the executed ones
	
	public Stack()
	{
		list = new ArrayList<Task>(); 
	}
	
	/**
	 * Stack will implement LIFO
	 * Last In First Out
	 */
	public void add(Task task)
	{
		list.add(task);
		pos++;
	}

	public void remove()
	{
		if(pos != 0)
		{
			list.remove(pos-1);
			pos --;
		}
		else
			System.out.println("Nothing to pop");
		
	}
	
	public Task execute()
	{
		if(count != pos)
		{
		list.get(count).execute();
		count++;
		
		return list.get(count-1);
		}
		
		//reinitialize execution
		count = 0;
		return null; //all of them have been executed
		
		/*
		for(int i = 0;i< pos;i++)
		{
			list.get(i).execute();
		}
		*/
		/*
		while(pos != 0)
			pop();
		*/
	}
	
}
