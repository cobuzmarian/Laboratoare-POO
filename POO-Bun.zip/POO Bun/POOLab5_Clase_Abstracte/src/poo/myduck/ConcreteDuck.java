package poo.myduck;

public class ConcreteDuck extends AbstractDuck implements GeneralDuck{

	public ConcreteDuck(boolean fly,String type){
		this.fly = fly;
		this.duckType = type;
	}

	/**
	 * Let's test its flying
	 */
	public void testFlight(){
		if(fly)
			System.out.println("Duck is flying");
		else
			System.out.println("This duck is grounded -.-");
	}
	
	@Override
	public void move() {
		System.out.println("Duck is moving");
	}

	@Override
	public void eat() {
		System.out.println("Duck is eating");		
	}
	
	
}
