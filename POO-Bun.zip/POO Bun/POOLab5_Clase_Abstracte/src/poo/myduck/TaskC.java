package poo.myduck;

public class TaskC implements Task{
	int contor;
	
	public TaskC()
	{
		for(int i = 0 ;i <=3; i++)
		{
			contor++;
			execute();
		}
		
		
	}
	@Override
	public void execute() {
		TaskA show = new TaskA(Integer.toString(contor));
	}

}
