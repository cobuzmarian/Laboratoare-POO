package poo.myduck;

public class TaskA implements Task{

	public String message;
	
	public TaskA(String message)
	{
		this.message = message;
		execute();
	}
	@Override
	public void execute() {
		System.out.println(message);
	}

	
}
