package poo.myduck;

public class CountTaskRunner extends AbstractTaskRunner{
	public int contor = 0;
	
	public CountTaskRunner(String type) {
		super(type);
	}

	@Override
	protected void action(Task task) {
		contor++;
		
	}

}
