package poo.myduck;

public class RedoTaskRunner extends AbstractTaskRunner{
	Container redo;
	
	public RedoTaskRunner(String type) {
		super(type);
	}

	@Override
	protected void action(Task task) {
		if(container instanceof Stack)
		{
			redo = new Queue();
			redo.add(task);
		}
		else
		if(container instanceof Queue)
		{
			redo = new Stack();
			redo.add(task);
		}
	}

}
