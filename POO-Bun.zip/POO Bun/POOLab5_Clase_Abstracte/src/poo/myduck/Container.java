package poo.myduck;

public interface Container {

	/**
	 * Partea comuna ar fi taskurile A, B si C
	 */
	public Task execute();
	public void add(Task task);
	public void remove();
}
