package poo.myduck;

public class ConcreteDuckTest {

	public static void ConcreteDuckTest()
	{
		ConcreteDuck myDuck = new ConcreteDuck(true,"salbatica");
		
		myDuck.testFlight();
		myDuck.quack();
	}
}
