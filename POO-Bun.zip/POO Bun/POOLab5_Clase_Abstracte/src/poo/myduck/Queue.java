package poo.myduck;

import java.util.ArrayList;

public class Queue implements Container{

	ArrayList<Task> list = new ArrayList<Task>(); 
	int pos = 0;
	int first = 0;
	int count = 0;
	
	public Queue()
	{
		list = new ArrayList<Task>(); 
	}
	
	/**
	 * Queue will implement FIFO
	 * First In First Out
	 */
	public void add(Task task)
	{
		list.add(task);
		pos++;
	}
	
	public void remove()
	{
		if(first != pos)
		{
			list.remove(0);
			first++;
			count = first;
		}
		else
			System.out.println("Nothing to remove !");
	}
	
	public Task execute()
	{
		if(count != pos)
		{
		list.get(count).execute();
		count++;
		
		return list.get(count-1);
		}
		
		count = 0;
		return null;
		
		/*
		for(int i = first;i< pos;i++)
		{
			list.get(i).execute();
		}
		*/
		/*while(pos != 0)
			remove();
		
		//reinitialize the first one with 0
		first = 0;*/
		
	}
}
