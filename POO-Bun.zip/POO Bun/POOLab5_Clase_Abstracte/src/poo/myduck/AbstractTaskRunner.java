package poo.myduck;

public abstract class AbstractTaskRunner {

	Container container;
	
	public AbstractTaskRunner(String type)
	{
		if(type.equals("LIFO"))
			container = new Stack();
		
		if(type.equals("FIFO"))
			container = new Queue();
	}
	
	public void addTask(Task task)
	{
		container.add(task);
	}
	
	public void executeAll()
	{
		Task newt = container.execute();
		while(newt != null)
		{	
			action(newt);
			newt = container.execute();
		}
		//while(container.execute() != null) // while there are tasks in the queue or task
		//	action();
	}
	
	protected abstract void action(Task task);
	
}
