package poo.myduck;

import java.util.Date;


public class PrintTaskRunner extends AbstractTaskRunner{

	public PrintTaskRunner(String type) {
		super(type);
	}

	@Override
	protected void action(Task task) {
		
		System.out.println(new Date().toString());
	}

}
