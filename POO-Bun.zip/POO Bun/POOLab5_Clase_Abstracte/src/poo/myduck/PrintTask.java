package poo.myduck;

public class PrintTask extends PrintTaskRunner{

	public PrintTask(String type) {
		super(type);
	}
	
	public void delay()
	{
		 try { 
			 //intarziere de o secunda
			 Thread.sleep(1000);  
			 } catch (InterruptedException e) { 
			 e.printStackTrace(); 
			 } 
	}
}
