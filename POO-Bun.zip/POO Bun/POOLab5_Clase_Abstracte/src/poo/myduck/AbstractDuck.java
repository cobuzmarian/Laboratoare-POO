package poo.myduck;

public abstract class AbstractDuck {

	String duckType;
	boolean fly;
	
	public void quack(){
		System.out.println("Quack Quack");
		
	}
	
}
