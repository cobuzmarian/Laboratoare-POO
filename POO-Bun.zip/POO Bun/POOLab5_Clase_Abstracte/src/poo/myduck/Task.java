package poo.myduck;

public interface Task {

	/**
	 * Afiseaza mesajul taskului
	 * @param message
	 */
	public void execute();
	
}
