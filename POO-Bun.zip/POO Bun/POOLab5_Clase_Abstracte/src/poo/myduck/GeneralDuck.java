package poo.myduck;

public interface GeneralDuck {

	/**
	 * Any duck can move
	 */
	public void move();
	
	/**
	 * All ducks eat
	 */
	public void eat();
}
