package poo.myduck;

import java.util.Random;

public class TaskB implements Task{

	int randomInt;
	public TaskB()
	{
		Random r = new Random();
		randomInt = r.nextInt();
		execute();
	}
	
	@Override
	public void execute() {
		TaskA show = new TaskA(Integer.toString(randomInt));
	}

}
