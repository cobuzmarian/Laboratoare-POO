package poo.lab5;

import poo.myduck.ConcreteDuckTest;

public class POOLab5 {

	public static void main(String[] args)
	{
		ConcreteDuckTest.ConcreteDuckTest();
	}
	
}
