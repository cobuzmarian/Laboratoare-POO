package com.poo.lab1;

import java.util.Scanner;


public class POO1{
	
		public static void main(String args[])
		{
			Scanner input = new Scanner(System.in);
		System.out.println("Ma plictisesc "+Oclasa.Test());
		System.out.println("Ce facem ?");
		  String Test = input.nextLine();
		  
		  System.out.println("Am afisat "+Test);
		}

}
