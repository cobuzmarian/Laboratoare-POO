package com.poo.lab1;

class Oclasa{

	public static int Test()
	{
		
		return 20;
	}
	
	
}