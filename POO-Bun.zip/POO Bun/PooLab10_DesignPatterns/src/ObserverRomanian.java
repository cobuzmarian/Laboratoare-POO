import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;


public class ObserverRomanian extends AbstractObserver{

	HashMap<String,String> map = new HashMap<String,String>();
	
	public ObserverRomanian()
	{
		
	}
	
	@Override
	public void update(String message)
	{
		translate(message);
		printMap();
	}

	@Override
	public void translate(String message) {
		map.put(message, "Translated into romanian");
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public void printMap() {
		Map mp = map;
	    Iterator it = mp.entrySet().iterator();
	    while (it.hasNext()) {
	        Map.Entry pairs = (Map.Entry)it.next();
	        System.out.println(pairs.getKey() + " = " + pairs.getValue());
	        it.remove(); // avoids a ConcurrentModificationException
	    }
	}

}
