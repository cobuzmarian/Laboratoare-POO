package factory;

import java.util.ArrayList;

public class Invoker {

	ArrayList<ImageCommand> list;
	int n;
	public Invoker() 
	{
		list = new ArrayList<ImageCommand>();
		n = 0;
	}
	
	public void addCommand(ImageCommand command)
	{
		list.add(command);
		n++;
	}
	
	public void undo()
	{
		if(n-- > 0)
		{
			System.out.println("Undo executed!");
			n--;
			list.get(n).executeCommand();
		}
	}
	
	public void redo()
	{
		if(n+1 < list.size())
		{
			System.out.println("Redo executed!");
			n++;
			list.get(n).executeCommand();
		}
	}
	
}
