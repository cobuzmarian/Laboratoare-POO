package factory;

public class Image {
	
	boolean size,crop;
	Invoker invoker;
	
	public Image(boolean size, boolean crop)
	{
		this.size = size;
		this.crop = crop;
		invoker = new Invoker();
	}
	
	public void applyCommand(boolean size,boolean crop)
	{
		invoker.addCommand(new Commands(size,crop,this));
		this.size = size;
		this.crop = crop;
	}
	
	public void showImage()
	{
		System.out.println("Crop "+crop+" Size "+ size);
	}
	
	public void undo()
	{
		invoker.undo();
	}
	
	public void redo()
	{
		invoker.redo();
	}
}
