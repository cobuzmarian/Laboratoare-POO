package factory;

public class ImageCommandFactory {

	Invoker invoker;
	public ImageCommandFactory()
	{
		invoker = new Invoker();
	}
	
	public ImageCommand CreateCommand(String type,Image image)
	{
		if(type.equals("resize"))
			return resizeCommand(image);
		
		if(type.equals("crop"))
			return cropCommand(image);
		
		return null;
	}
	
	public ImageCommand resizeCommand(Image image)
	{
		invoker.addCommand(new Commands(false,true,image));
		return new Commands(true,false,image);
	}
	
	public ImageCommand cropCommand(Image image)
	{
		invoker.addCommand(new Commands(false,true,image));
		return new Commands(false,true,image);
	}
	
}
