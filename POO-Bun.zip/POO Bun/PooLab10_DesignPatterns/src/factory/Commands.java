package factory;

public class Commands extends ImageCommand{
	
	boolean size,crop;
	Image image;
	
	public Commands(boolean size, boolean crop, Image image)
	{
		this.size = size;
		this.crop = crop;
		this.image = image;
	}

	@Override
	public void executeCommand() {
		image.applyCommand(size, crop);
		image.showImage();
	}
}