package factory;

public abstract class ImageCommand {
	
	public abstract void executeCommand();

}
