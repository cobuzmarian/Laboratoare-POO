import factory.Image;
import factory.ImageCommandFactory;


public class Main {

	public static void main(String[] args)
	{
		MessageSet test = new MessageSet();
		
		Observer obs = new Observer();
		ObserverRomanian obsr = new ObserverRomanian();
		test.attach(obs);
		test.attach(obsr);
		
		test.addMessage("ce faci?");
		System.out.println("-------------");
		test.addMessage("fac POO");
		
		System.out.println();
		System.out.println();
		
		ImageCommandFactory factory = new ImageCommandFactory();
		Image img = new Image(false,false);
		
		factory.CreateCommand("crop",img).executeCommand();
		factory.CreateCommand("resize",img).executeCommand();
		
		img.undo();
	}
}
