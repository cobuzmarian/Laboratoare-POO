import java.util.HashMap;

public abstract class AbstractObserver {
	
	HashMap<String,String> map = new HashMap<String,String>();
	
	public abstract void update(String message);
	
	public abstract void translate(String message);

	public abstract void printMap() ;
}
