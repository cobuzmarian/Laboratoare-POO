import java.util.ArrayList;
import java.util.Iterator;


public class MessageSet {

	ArrayList<String> list;
	ArrayList<AbstractObserver> obsList = new ArrayList<AbstractObserver>();
	
	public MessageSet()
	{
		list = new ArrayList<String>();
	}
	
	public void addMessage(String message)
	{
		list.add(message);
		notifyObservers(message);
	}
	
	public void attach(AbstractObserver observer)
	{
		obsList.add(observer);
	}
	
	public void notifyObservers(String message)
	{
		Iterator<AbstractObserver> it = obsList.iterator();
		while(it.hasNext())
		{
			AbstractObserver obs = it.next();
			obs.update(message);
		}
	}
	
}
