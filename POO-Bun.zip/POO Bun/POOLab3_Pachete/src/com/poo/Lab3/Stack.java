package com.poo.Lab3;

public class Stack {
	private Array stack = new Array();
	private int cursor = 0;
	
	public void push(int number)
	{
		stack.Add(number);
		cursor++;
	}
	
	public void pop(int number)
	{
		stack.remove(cursor);
		cursor--;
	}
	
	public boolean isEmpty()
	{
		if(stack.size() == 0)
			return true;
		else
			return false;
	}
	
	public String toString()
	{
		return stack.toString();
	}
	
}
