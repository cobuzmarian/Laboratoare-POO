package com.poo.Lab3;

public class Array {

	private int[] vector;
	private int dim;
	private int cursor = 0;
	
	public Array()
	{	
		vector = new int[10];
		dim = 10;
	}
	
	public Array(int dimensiune)
	{
		dim = dimensiune;
		vector = new int[dimensiune];
	}
	
	protected void Add(int number)
	{	
	
		if(cursor < vector.length)
		{
			vector[cursor] = number;
			cursor++;
		}
		else
		{
			int[] vectorCopy = new int[this.dim];
			System.arraycopy(vector, 0, vectorCopy, 0, vector.length);
			this.dim = this.dim * 2;
			vector = new int[this.dim];
			System.arraycopy(vectorCopy, 0, vector, 0, vectorCopy.length);
			vector[vectorCopy.length] = number;
			cursor++;
		}
		

	}
	
	public boolean Contains(int number)
	{
		boolean statement = false;
		
		for(int i = 0; i< cursor;i++)
			if(vector[i] == number)
				statement = true;
		
		return statement;
	}
	
	public int size()
	{
		return cursor;
	}
	
	public int get(int pos)
	{
		return vector[pos];
	}
	
	public String toString()
	{
		StringBuffer str = new StringBuffer();
		
		for (int i = 0; i < cursor; i++) {
			if(i != cursor -1)
			   str.append( vector[i]+"," );
			else
			   str.append( vector[i] );
		}
		
		String result = str.toString();
		
		return result;
	}
	
	public void remove(int pos)
	{
		for(int i=pos;i<cursor-1;i++)
		{
			vector[i] = vector[i+1];
		}
		
		cursor--;
	}
}

