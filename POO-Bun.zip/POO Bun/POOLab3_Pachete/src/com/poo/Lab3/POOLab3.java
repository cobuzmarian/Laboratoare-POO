package com.poo.Lab3;

import java.util.Random;

public class POOLab3 {

	public static void main(String args[])
	{
		Array test = new Array();
		Random r = new Random();
		test.Add(23);
		System.out.println("Test contains 23 :" + test.Contains(23));
		System.out.println("Test contains 33 :" + test.Contains(33));
		
		System.out.println("Line 0 from test "+test.get(0));
		
		System.out.println("The size of the vector is "+test.size());
		
		for(int i=0;i<30;i++)
			test.Add(r.nextInt(100));
		
		System.out.println("The vector is " + test.toString());
		System.out.println("The vector size is "+test.size());
		
		Stack stest = new Stack();
		stest.push(23);
		stest.push(30);
		stest.pop(30);
		System.out.println("The stack is "+stest.toString());
		
		
		StackExt stest2 = new StackExt();
		
	} 
}
