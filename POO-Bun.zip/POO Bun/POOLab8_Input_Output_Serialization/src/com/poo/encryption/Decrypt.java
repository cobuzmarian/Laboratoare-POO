package com.poo.encryption;

import java.io.IOException;
import java.io.InputStream;

public class Decrypt {
	
	InputStream source;
	public Decrypt(InputStream source)
	{
		this.source = source;
		
	}

	public int read() throws IOException {
		if(source.read() != -1)
			return source.read()-1;
		else
			return -1;
	}
	
}
