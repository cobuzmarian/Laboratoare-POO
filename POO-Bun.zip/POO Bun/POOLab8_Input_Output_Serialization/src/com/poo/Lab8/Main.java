package com.poo.Lab8;

public class Main {

	public static void main(String args[])
	{
		if(args[0].equals("cp"))
		{
			if(!args[1].isEmpty() && !args[2].isEmpty())
			{
				new cp(args[1],args[2]);
			}
		}
		
		if(args[0].equals("cpCrypt"))
		{
			if(!args[1].isEmpty() && !args[2].isEmpty())
			{
				new cpCrypt(args[1],args[2]);
			}
		}
		
		if(args[0].equals("wc"))
		{
			if(args.length < 3)
			{	
				if(!args[1].isEmpty())
					new wc(args[1],false);
			}
			else
			{
				if(args[2].equals("-1"))
				{	
					if(!args[1].isEmpty())
						new wc(args[1],true);
				}
				else
				{
					new wc(args[1],false);
				}
			}
			
		}
		
		if(args[0].equals("wcCrypt"))
		{
			if(args.length < 3)
			{	
				if(!args[1].isEmpty())
					new wcCrypt(args[1],false);
			}
			else
			{
				if(args[2].equals("-1"))
				{	
					if(!args[1].isEmpty())
						new wcCrypt(args[1],true);
				}
				else
				{
					new wcCrypt(args[1],false);
				}
			}
			
		}
		
		if(args[0].equals("grep"))
		{
			if(args.length > 2)
			{	
				if(!args[1].isEmpty() && !args[2].isEmpty())
					new grep(args[1],args[2]);
			}
			
		}
		
		CircularList test = new CircularList(4);
		test.serialize();
		test.deserialize();
	}
	
	
}
