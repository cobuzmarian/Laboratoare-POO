package com.poo.Lab8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class grep {

	public grep(String sursa,String cuvant)
	{
		try {
			findWord(sursa,cuvant);
		} catch (FileNotFoundException e) {
			System.out.println("File not found !");
		}
	}
	
	public void findWord(String sursa,String cuvant) throws FileNotFoundException
	{
		File file = new File(sursa);
		Scanner sc = new Scanner(new FileInputStream(file));
		int count = 0;
		while(sc.hasNext()){
			
			String line = sc.nextLine();
			if(line.contains(cuvant))
			{
				System.out.println("Numarul liniei este "+count);
				System.out.println(line);
				break;
			}
			
			count++;
		}
		
		sc.close();
	}
	
}
