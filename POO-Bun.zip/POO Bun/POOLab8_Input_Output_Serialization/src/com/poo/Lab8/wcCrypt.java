package com.poo.Lab8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Scanner;

import com.poo.encryption.Decrypt;

public class wcCrypt {

	public wcCrypt(String sursa,boolean lines)
	{
		if(!lines)
			try {
				countWords(sursa);
			} catch (IOException e) {
				e.printStackTrace();
			}
		else
			try {
				countLines(sursa);
			} catch (IOException e) {
				e.printStackTrace();
			}
	
	}
	
	public void countWords(String sursa) throws IOException
	{
		File file = new File(sursa);
		
		Decrypt dec = new Decrypt(new FileInputStream(file));
		File temp = new File("temp");
		OutputStream os = null;
        os = new FileOutputStream(temp);
        int length;
        while ((length = dec.read()) > 0) {
        	os.write(length);
        }
        
        os.close();
        
		Scanner sc = new Scanner(new FileInputStream(temp));
		int count=0;
		while(sc.hasNext()){
		    sc.next();
		    count++;
		}
		
		sc.close();
		
		temp.delete();
		System.out.println(count+" words");
	}
	
	public void countLines(String sursa) throws IOException
	{
		File file = new File(sursa);
		
		Decrypt dec = new Decrypt(new FileInputStream(file));
		File temp = new File("temp");
		OutputStream os = null;
        os = new FileOutputStream(temp);
        int length;
        while ((length = dec.read()) > 0) {
        	os.write(length);
        }
        
        os.close();
        
		Scanner sc = new Scanner(new FileInputStream(temp));
		int count=0;
		while(sc.hasNext()){
		    sc.next();
		    count++;
		}
		
		sc.close();
		
		temp.delete();
		
		System.out.println(count+" lines");
	}
	
}
