package com.poo.Lab8;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

public class CircularList implements Serializable{

	/**
	 * The serial id
	 */
	private static final long serialVersionUID = -5931886891891400884L;

	int n;
	ArrayList<Integer> al;
	public CircularList(int n)
	{
		this.n = n;
		Random r = new Random();
		
		ArrayList<Integer> test = new ArrayList<Integer>();
		for(int i = 0;i<n;i++)
			test.add(r.nextInt(20));
		
		this.al = test;
	}
	
	public void serialize()
	{
	      try{
	          FileOutputStream fos= new FileOutputStream("myfile");
	          ObjectOutputStream oos= new ObjectOutputStream(fos);
	          oos.writeObject(al);
	          oos.close();
	          fos.close();
	        }catch(IOException ioe){
	             ioe.printStackTrace();
	         }
	}
	
	public void deserialize()
	{
		ArrayList<Integer> arraylist;
		  try
	        {
	            FileInputStream fis = new FileInputStream("myfile");
	            ObjectInputStream ois = new ObjectInputStream(fis);
	            arraylist = (ArrayList<Integer>) ois.readObject();
	            ois.close();
	            fis.close();
	         }catch(IOException ioe){
	             ioe.printStackTrace();
	             return;
	          }catch(ClassNotFoundException c){
	             System.out.println("Class not found");
	             c.printStackTrace();
	             return;
	          }
		  
			for(Integer tmp: arraylist){
	            System.out.println(tmp);
	        }
	}
}
