package com.poo.Lab8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import com.poo.encryption.Encrypt;

public class cpCrypt {

	public cpCrypt(String sursa,String destinatie)
	{
		try {
			copy(sursa,destinatie);
		} catch (FileNotFoundException e) {
			System.out.println("File not found !");
		} catch (IOException e) {
			System.out.println("File not found !");
		}
	}
	
	public void copy(String sursa,String destinatie) throws FileNotFoundException,IOException
	{
		File source = new File(sursa);
		File dest = new File(destinatie);
		
		Encrypt is = null;
	    OutputStream os = null;
	        is = new Encrypt(new FileInputStream(source));
	        os = new FileOutputStream(dest);
	        int length;
	        while ((length = is.read()) > 0) {
	        	os.write(length);
	        }
				is.close();
				os.close();
	        
	 }
	    
}
