package com.poo.Lab8;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class wc {

	public wc(String sursa,boolean lines)
	{
		if(!lines)
			try {
				countWords(sursa);
			} catch (FileNotFoundException e) {
				System.out.println("File not found !");
			}
		else
			try {
				countLines(sursa);
			} catch (FileNotFoundException e) {
				System.out.println("File not found !");
			}
		
		
	}
	
	public void countWords(String sursa) throws FileNotFoundException
	{
		File file = new File(sursa);
		Scanner sc = new Scanner(new FileInputStream(file));
		int count=0;
		while(sc.hasNext()){
		    sc.next();
		    count++;
		}
		
		sc.close();
		
		System.out.println(count+" words");
	}
	
	public void countLines(String sursa) throws FileNotFoundException
	{
		File file = new File(sursa);
		Scanner sc = new Scanner(new FileInputStream(file));
		int count=0;
		while(sc.hasNext()){
			sc.nextLine();
		    count++;
		}
		
		sc.close();
		
		System.out.println(count+" lines");
	}
}
