package lab10;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

public class MotenireLinkedList extends LinkedList<Integer>{

	int n = 0;
	
	public MotenireLinkedList()
	{
		
	}
	
	public void add(int test)
	{
		n++;
		super.add(test);
	}
	
	public boolean addAll(Collection<? extends Integer> arg0)
	{
		Iterator<Integer> it = (Iterator<Integer>) arg0.iterator();
		while(it.hasNext())
		{
			n++;
			super.add(it.next());
		}
		
		return true;
	}
	
	public int getSize()
	{
		return n;
	}
}
