package lab10;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import exceptions.DuplicateException;

public class ColectieStudenti {

	Collection<Student> colectie;
	
	public ColectieStudenti()
	{
		colectie = new ArrayList<Student>();
	}
	
	public void add(Student stud) throws DuplicateException
	{
		if(checkExists(stud))
			throw new DuplicateException("The student "+stud.toString()+" already exists!");
		else
			colectie.add(stud);
	}
	
	public boolean checkExists(Student stud)
	{
		Iterator<Student> it = colectie.iterator();
		while(it.hasNext())
		{
			Student test = it.next();
			
			if(test.equals(stud))
				return true;
		}
		
		return false;
	}
	
	public String toString()
	{
		return colectie.toString();
	}
}
