package lab10;

public class Student implements Comparable {
	
	String nume;
	float media;
	
	public Student(String nume,float media)
	{
		this.nume = nume;
		this.media = media;
	}
	
	public Student()
	{
		
	}
	
	public String getName()
	{
		return this.nume;
	}
	
	public float getMedia()
	{
		return this.media;
	}
	
	public boolean equals(Student stud)
	{
		return false;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(media);
		result = prime * result + ((nume == null) ? 0 : nume.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (Float.floatToIntBits(media) != Float.floatToIntBits(other.media))
			return false;
		if (nume == null) {
			if (other.nume != null)
				return false;
		} else if (!nume.equals(other.nume))
			return false;
		return true;
	}

	public String toString()
	{
		return "["+nume+","+media+"]";
	}

	public int compareTo(Object arg0) {
		if(arg0 instanceof Student)
		{
			Student arg = (Student) arg0;
			
			if(arg.getName().equals(this.nume)  && arg.getMedia() == this.media)
			{
				if(arg.getMedia() > this.media)
					return 1;
				else
				if(arg.getMedia() == this.media)
					return 0;
				else
					return -1;
			}
			else
				return this.nume.compareTo(arg.getName());
		}
		
		return 0;
	}
	

}
