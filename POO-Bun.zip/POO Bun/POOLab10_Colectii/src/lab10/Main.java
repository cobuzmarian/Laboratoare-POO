package lab10;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;

public class Main {

	public static void main(String args[])
	{
		/*
		Colectie test = new Colectie();
		
		try {
			test.add("test");
			test.add("test");
		} catch (DuplicateException e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println(test.toString());
		*/
		
		/*
		ColectieStudenti test2 = new ColectieStudenti();

		try {
			test2.add(new Student("Grigore",20));
			test2.add(new Student("Grigore",20));
		} catch (DuplicateException e) {
			System.out.println(e.getMessage());
		}
		
		System.out.println(test2.toString());
		*/
		
		/*
		HashSet<Student> test3 = new HashSet<Student>();
		
		test3.add(new Student("Test",20));
		test3.add(new Student("Test",20));
		test3.add(new Student("Gheorghe",12));
		
		Iterator<Student> it2 = test3.iterator();
		while(it2.hasNext())
		{
			Student teststud = it2.next();
			
			System.out.println(teststud.equals(teststud));
			System.out.println(((Object) teststud).equals(teststud));
		}
		*/
	//	System.out.println(test3.toString());
		
		/*
		Map test = new Map();
		
		test.add(new Student("Balaurul",2.3f));
		test.add(new Student("Ion",2.2f));
		test.add(new Student("Razvan",5.9f));
		test.add(new Student("Razvan",5.4f));


		
		 Set<Integer> keys = test.keySet();
		 
	     for(Integer key: keys){
	    	 
	    	 	ArrayList<Student> lista = test.get(key);
	    	 	
	    	 	Collections.sort(lista, new Comparator<Student>() {
	    	 	    public int compare(Student v1, Student v2) {
	    	 	    	return v1.compareTo(v2);
	    	 	    }
	    	 	});
	    	 	
	            System.out.println("Value of "+key+" is: "+test.get(key));
	            
	     }
		 */
		
		Random random = new Random();
		
		ArrayList<Integer> rarray = new ArrayList<Integer>();
		double time;
		
		time = System.currentTimeMillis();
		for(int i = 0; i< 200000;i++)
			rarray.add(random.nextInt(1000));
		
		for(int i = 0; i< 10000;i++)
			rarray.get(random.nextInt(100000));
		
		time = System.currentTimeMillis() - time;
		System.out.println("ARRAYLIST "+  time);
		
		
		LinkedList<Integer> rlist = new LinkedList<Integer>();
		
		time = System.currentTimeMillis();
		for(int i = 0; i< 200000;i++)
			rlist.add(random.nextInt(1000));
			
		for(int i = 0; i< 10000;i++)
			rlist.get(random.nextInt(100000));
		
		time = System.currentTimeMillis() - time;
		System.out.println("LINKEDLIST "+  time);
		
		/*
		Mostenire test = new Mostenire();
		
		for(int i = 0;i< 20;i++)
			test.add(random.nextInt(100));
		
		test.addAll(rarray);
		
		System.out.println(test.getSize());
		System.out.println(test.globalSize());
		*/
	}
}
