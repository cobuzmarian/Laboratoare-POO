package lab10;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class Mostenire extends HashSet<Integer>{

	int n;
	
	public Mostenire(){ }
	
	public void add(int test)
	{
		n++;
		super.add(test);
	}
	
	public boolean addAll(Collection<? extends Integer> arg0)
	{
		Iterator<Integer> it = (Iterator<Integer>) arg0.iterator();
		while(it.hasNext())
		{
			n++;
			super.add(it.next());
		}
		
		return true;
	}
	
	public int getSize()
	{
		return n;
	}
	
	public int globalSize()
	{
		return super.size();
	}
}
