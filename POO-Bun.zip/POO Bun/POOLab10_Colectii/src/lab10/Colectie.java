package lab10;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import exceptions.DuplicateException;

public class Colectie {

	Collection<String> colectie;
	
	public Colectie()
	{
		colectie = new HashSet<String>();
	}
	
	public void add(String test) throws DuplicateException
	{
		colectie.add(test);
		/*
		if(colectie.contains(test))
			throw new DuplicateException("The string "+test+" already exists!");
		else
			colectie.add(test);
		*/
	}
	
	public String toString()
	{
		return colectie.toString();
	}
}
