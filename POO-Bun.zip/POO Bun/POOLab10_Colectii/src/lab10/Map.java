package lab10;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

public class Map {

	TreeMap<Integer,ArrayList<Student>> map;
	
	public Map()
	{
		map = new TreeMap<Integer,ArrayList<Student>>();
	}
	
	
	public void add(Student stud)
	{
		
		int key = (int) stud.getMedia();
		
		if(map.containsKey(key))
		{
			ArrayList<Student> lista = map.get(key);
			lista.add(stud);
			
			map.put(key, lista);
		}
		else
		{
			ArrayList<Student> lista = new ArrayList<Student>();
			lista.add(stud);
			map.put(key, lista);
		}
		
	}
	
	public void replace(int key,ArrayList<Student> lista)
	{
		map.put(key,lista);
	}
	
	public Set<Integer> keySet()
	{
		return map.keySet();
	}
	
	public ArrayList<Student> get(Integer key)
	{
		return map.get(key);
	}
}
