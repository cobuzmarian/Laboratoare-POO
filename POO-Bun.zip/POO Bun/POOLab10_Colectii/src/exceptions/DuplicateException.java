package exceptions;

public class DuplicateException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -751474947602981550L;

	public DuplicateException(String message){
		super(message);
	}

}
