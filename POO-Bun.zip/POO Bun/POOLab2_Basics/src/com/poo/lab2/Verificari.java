package com.poo.lab2;

public class Verificari {

	
	public static Boolean DubluExemplar(Carte c1,Carte c2)
	{
		if(c1.autor.equals(c2.autor) && c1.editura.equals(c2.editura)  && c1.titlu.equals(c2.titlu) 
				&& c1.numarPagini == c2.numarPagini)
			return true;
		
		
			return false;
	}
	
	public static Carte Groasa(Carte c1,Carte c2)
	{
		if(c1.numarPagini > c2.numarPagini )
			return c1;
		else
			return c2;
	}
	
}
