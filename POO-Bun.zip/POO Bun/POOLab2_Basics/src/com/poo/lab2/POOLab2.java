package com.poo.lab2;

import java.util.Scanner;

public class POOLab2 {

	public static void main(String args[])
	{		
		NumarComplex();
				
		System.out.println("Introduceti 2 carti de la tastatura : ");
		Carte c1 = citesteCarte();
		Carte c2 = citesteCarte();
		
		if(Verificari.DubluExemplar(c1, c2))
			System.out.println("Cartea este in dublu exemplar !");
		else
			System.out.println("Cartea NU este in dublu exemplar !");
		
		
		System.out.println("Cartea mai groasa este cea cu titlul " + Verificari.Groasa(c1, c2).titlu);
	}
	
	public static Carte citesteCarte()
	{
		Carte biblioteca = new Carte();
		Scanner input = new Scanner(System.in);
		
		System.out.println("Introduceti titlu cartii ");
		biblioteca.titlu = input.nextLine();
		
		System.out.println("Introduceti editura cartii ");
		biblioteca.editura = input.nextLine();
		
		System.out.println("Introduceti autorul cartii ");
		biblioteca.autor = input.nextLine();
		
		System.out.println("Introduceti numarul de pagini ");
		int nrPag = input.nextInt();
		
		while(nrPag == 0 )
		{
			System.out.println("Numarul nu are voie sa fie zero. Introduceti din nou ! ");
			nrPag = input.nextInt(); 
		}
		
		biblioteca.numarPagini = nrPag;
		
		
		return biblioteca;
	}
	
	public static void NumarComplex()
	{
		NumereComplexe x1 = new NumereComplexe();
		x1.re = (float) 0.1;
		x1.im = (float) 0.7;
		
		NumereComplexe x2 = new NumereComplexe();
		x2.re = (float) 1.8;
		x2.im = (float) 1.2;
		
		NumereComplexe adunat = Operatii.adunare(x1, x2);
		NumereComplexe inmultit = Operatii.inmultire(x1, x2);
		
		System.out.println("Adunarea celor 2 numere este "+adunat.re+" "+adunat.im);
		System.out.println("Inmultirea celor 2 numere este "+inmultit.re+" "+inmultit.im);
		
	}
}
