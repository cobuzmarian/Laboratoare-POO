package com.poo.lab2;

public class NumereComplexe {
	
	public float re,im;
	
}
