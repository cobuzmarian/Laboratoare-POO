package com.poo.lab2;

import java.util.ArrayList;

public class Carte {

	public String titlu,autor,editura;
	public Integer numarPagini;
	
}
