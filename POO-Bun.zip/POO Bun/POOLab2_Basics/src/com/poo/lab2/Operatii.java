package com.poo.lab2;

public class Operatii {


	public static NumereComplexe adunare(NumereComplexe nr1,NumereComplexe nr2)
	{
		NumereComplexe suma = new NumereComplexe();
		suma.re = nr1.re + nr2.re;
		suma.im = nr1.im + nr2.im;
		
		return suma;
	}

	public static NumereComplexe inmultire(NumereComplexe nr1,NumereComplexe nr2)
	{
		NumereComplexe inmultit = new NumereComplexe();
		inmultit.re = nr1.re * nr2.re;
		inmultit.im = nr1.im * nr2.im;
		
		return inmultit;
	}
	
}
