package poo.LAB6;

import java.util.Random;

public class EncrypterFactory {

	public EncrypterFactory(){
		
	}
	
	public Encrypter get(){
		Random r = new Random();
		
		if(r.nextInt(2) == 1)
		{
			Encrypter test = new EncryptA1();
			return test;
		}
		else
		{
			Encrypter test = new EncryptA2();
			return test;
		}
		
	}
	
	public class EncryptA1 implements Encrypter{
		public EncryptA1(){
			
		}
		
		/**
		 * Primul tip de encriptie ASCII x + 1
		 */
		@Override
		public String encrypt(String value) {
			char[] eval = value.toCharArray();
			
			for(int i = 0;i< value.length();i++)
				eval[i] = (char) (eval[i] + 1);

			return new String(eval);
		}
		
		/**
		 * Primul tip de decriptie
		 */
		@Override
		public String decrypt(String value) {
		char[] eval = value.toCharArray();
			
			for(int i = 0;i< value.length();i++)
				eval[i] = (char) (eval[i] - 1);

			return new String(eval);
		}
		
	}

	public class EncryptA2 implements Encrypter{
		public EncryptA2(){
			
		}
		
		@Override
		public String encrypt(String value) {
		char[] eval = value.toCharArray();
			
			for(int i = 0;i< value.length();i++)
				eval[i] = (char) (eval[i] - 5);

			return new String(eval);
		}

		@Override
		public String decrypt(String value) {
		char[] eval = value.toCharArray();
			
			for(int i = 0;i< value.length();i++)
				eval[i] = (char) (eval[i] + 5);

			return new String(eval);
		}
		
	}
	
}
