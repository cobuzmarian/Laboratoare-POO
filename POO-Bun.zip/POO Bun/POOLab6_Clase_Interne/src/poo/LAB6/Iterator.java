package poo.LAB6;

public interface Iterator {

	/**
	 * Returneaza boolean daca mai exista elemente in iterator
	 * @return
	 */
	public boolean hasNext();
	
	/**
	 * Intoarce urmatorul element si avanseaza in lista
	 * @return
	 */
	public Object getNext();
}
