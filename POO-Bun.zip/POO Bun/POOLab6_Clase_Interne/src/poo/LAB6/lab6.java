package poo.LAB6;

public class lab6 {

	public static void main(String args[])
	{
		Array test = new Array();
		test.add(20);
		test.add(10);
		test.add(20);
		test.add(10);
		test.add(20);
		test.add(10);
		
		Iterator it = test.iterator();
		int j = 0;
		while(it.hasNext())
		{
			if (j++ == 2) test.remove(2);
			try{
				System.out.println(it.getNext());
			}catch(ArrayIndexOutOfBoundsException ex)
			{
				System.out.println(ex.getMessage());
				break;
			}
		}

		
		EncrypterFactory testE = new EncrypterFactory();
		Encrypter e = testE.get();
		
		String ptest = "aaa";
		ptest = e.encrypt(ptest);
		System.out.println("Encrypted este " + ptest);
		
		ptest = e.decrypt(ptest);
		System.out.println("Decrypted este " + ptest);
	}
	

}
