package poo.LAB6;

public interface Encrypter {

	/**
	 * Intoarce stringul criptat
	 * @return
	 */
	public String encrypt(String value);
	
	/**
	 * Intoarce stringul decriptat
	 * @return
	 */
	public String decrypt(String value);
	
}
