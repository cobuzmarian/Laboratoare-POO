package interfaces;

public interface Sumabil {

	public void addValue(Sumabil value);
	
}
