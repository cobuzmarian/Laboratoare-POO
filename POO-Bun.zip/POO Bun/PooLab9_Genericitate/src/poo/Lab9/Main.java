package poo.Lab9;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.PriorityQueue;

import exercitiu4.MyMatrix;
import exercitiu4.MyVector3;
import interfaces.Sumabil;

public class Main {

	public static void main(String args[])
	{
		Coada<Integer> test = new Coada<Integer>();
		test.add(3);
		test.add(4);
		
		Iterator<Integer> it = test.iterator();

		while(it.hasNext())
			System.out.println(it.next());
		
		System.out.println("----------------------");
		
		PriorityQueue<Integer> queue = new PriorityQueue<Integer>();
		queue.add(2);
		queue.add(3);
		
		Coada<Integer> test2 = copyToCoada(queue);
		
		Iterator<Integer> it2 = test2.iterator();
		
		while(it2.hasNext())
			System.out.println(it2.next());
		
		ArrayList<Sumabil> sum = new ArrayList<Sumabil>();
		
		sum.add(new MyVector3(3));
		sum.add(new MyMatrix(4));
		
		System.out.println(addAll(sum));
	}
	
	public static <T extends Sumabil> T addAll(ArrayList<T> test)
	{
		Iterator<T> it = test.iterator();
		T suma = it.next();
		
		while(it.hasNext())
			suma.addValue(it.next());
		
		return suma;
	}
	
	public  static <T extends Number> Coada<T>  copyToCoada(PriorityQueue<T> queue)
	{
		 	Coada<T> test = new Coada<T>();
		 	
			Iterator<T> it = queue.iterator();
			
			while(it.hasNext())
				test.add(it.next());
			
			return test;
	}
}
