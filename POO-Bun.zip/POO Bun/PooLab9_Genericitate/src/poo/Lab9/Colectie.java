package poo.Lab9;

import java.util.Iterator;
import java.util.PriorityQueue;

public class Colectie <T extends Number>{

	PriorityQueue<T> queue;
	public Colectie()
	{
		queue = new PriorityQueue<T>();
	}
	
	public void add(T value)
	{
		queue.add(value);
	}
	
	public void copyToCoada(Coada<T> test)
	{
		Iterator<T> it = queue.iterator();
		
		while(it.hasNext())
			test.add(it.next());
	}
	
}
