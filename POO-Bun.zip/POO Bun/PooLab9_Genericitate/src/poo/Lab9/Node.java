package poo.Lab9;

public class Node <T>{

	private T value;
	private Node<T> next;
	
	public Node(T value)
	{
		next = new Node<T>();
		this.value = value;
	}
	
	public Node(){ }
	
	public Node<T> getNext()
	{
		return next;
	}
	
	public void setNext(Node<T> elem)
	{
		next = elem;
	}
	
	public T getValue()
	{
		return value;
	}
	
}
