package poo.Lab9;

import java.lang.Number;
import java.util.Iterator;

public class Coada <T extends Number> {

	public Node<T> first;
	public int number = 0;
	
	public Coada()
	{
		first = new Node<T>();
		first.setNext(null);
	}
	
	public void add(T value)
	{
		Node<T> add = new Node<T>(value);
		Node<T> current = first;
		
		while(current.getNext() != null)
			current = current.getNext();
		
		current.setNext(add);
		
		current.getNext().setNext(null);
	}
	
	public CoadaIterator iterator(){
		return new CoadaIterator();
	}
	
	public class CoadaIterator implements Iterator<T>{

		Node<T> current;
		public CoadaIterator()
		{
			current = first;
		}
		
		@Override
		public boolean hasNext() {
			if(current.getNext() != null)
				return true;
			
			return false;
		}

		@Override
		public T next() {
			Node<T> deReturnat = current.getNext();
			current = current.getNext();
			
			return deReturnat.getValue();
		}
		
	}
}
