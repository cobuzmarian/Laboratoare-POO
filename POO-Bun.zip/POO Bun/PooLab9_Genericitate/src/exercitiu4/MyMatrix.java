package exercitiu4;

import java.util.Random;

import interfaces.Sumabil;

public class MyMatrix implements Sumabil{

	int[][] matrice;
	
	public MyMatrix(int number)
	{
		Random random = new Random();
		
		for(int i =0;i < number;i++)
			matrice[i][i] = random.nextInt(20);
	}

	@Override
	public void addValue(Sumabil value) {
		
	}
}
