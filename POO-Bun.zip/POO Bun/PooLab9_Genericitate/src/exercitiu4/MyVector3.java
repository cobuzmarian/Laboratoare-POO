package exercitiu4;

import java.util.Random;

import interfaces.Sumabil;

public class MyVector3 implements Sumabil{

	public int[][][] test;
	
	public MyVector3(int number)
	{
		Random random = new Random();
		
		for(int i =0;i < number;i++)
			test[i][i][i] = random.nextInt(20);
	}

	@Override
	public void addValue(Sumabil value) {
		
	}
	
}
