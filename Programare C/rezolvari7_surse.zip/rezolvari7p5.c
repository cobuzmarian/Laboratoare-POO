/* 
 * Problema 5
 */

# include <stdio.h>
# include <string.h>

char* substr(char* src, int n, char* dest)
{
	strncpy(dest, src, n);
	if (n <= strlen(src)) 
		dest[n] = '\0';
	return dest;
}

int main()
{
	char s[100],subs[100];
	int poz,len;

	scanf("%s %d %d",s, &poz, &len);

	substr(s + poz, len, subs);

	printf("%s",subs);

	printf("\n");

	return 0;
}

