/*
 * Problema 9
 */

# include <stdio.h>
# include <ctype.h>

void incrementeaza_timp(int *h, int *m, int *s, char *sufix)
{
	(*s)++;

	sufix[0] = toupper(sufix[0]);
	sufix[1] = toupper(sufix[1]);

	if (*s > 59) {
		*s = 0;
		(*m)++;
		}
	else return;

	if (*m > 59) {
		*m = 0;
		(*h)++;
		}
	else return;

	if (sufix[0] == 'P' && *h >= 12) {
		*h = 0;
		sufix[0] = 'A';
		return;
		}

	if (sufix[0] == 'A' && *h >= 13) {
		*h = 1;
		sufix[0] = 'P';
		return;
		}
}

int main()
{
	int h,m,s;
	char sufix[3];

	scanf("%d %d %d %s", &h, &m, &s, sufix);

	incrementeaza_timp(&h, &m, &s, sufix);

	printf("%02d:%02d:%02d %s\n",h, m, s, sufix);

	return 0;
}
