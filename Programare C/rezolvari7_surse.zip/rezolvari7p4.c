/*
 * Problema 4
 */

# include <stdio.h>
# include <string.h>

char* strdel(char* p, int n)
{
	//caz 1: nu exista mai mult de n caractere incepand de la pozitia p
	if (strlen(p) <= n) {
		*p = '\0';
		return p;
		}

	//in caz contrar, facem stergerea copiind caracterele de la p+n peste cele de la p
	strcpy(p, p + n);
	return p;
}

char* strins(char* p, char *s)
{
	//pas 1: copiem sirul din p intr-o alta locatie
	char *tail_p = strdup(p);

	//pas 2: copiem la pozitia p noul sir
	strcpy(p, s);

	//pas 3: copiem la sfarsit caracterele care existau inainte in p
	strcat(p, tail_p);

	return p;
}

int main()
{
	char s[100],replacethis[100],withthis[100];

	
	gets(s);
	scanf("%s %s", replacethis, withthis);

	char *p;

	// pornim cu p fiind prima aparitie a sirului <replacethis> in sirul <s>
	// atata timp cat mai exista aparitii, facem inlocuirea si setam "p" ca fiind adresa urmatoarei
	// aparitii a sirului <replacethis> in <s>
	//
	// ATENTIE! este foarte important sa dam p=strstr(p+strlen(withthis),...) pentru ca in caz contrar programul ar cicla la infinit daca sirul <replacethis> se regaseste in <withthis>
	// Cu alte cuvinte, am inlocui in inlocuire, in locuire, in inlocuire...
	for (p = strstr(s, replacethis); p != NULL; p = strstr(p + strlen(withthis), replacethis)){
		strdel(p, strlen(replacethis));
		strins(p, withthis);
	}

	printf("%s\n", s);	

	return 0;
}

