/*
 * Problema 6
 */

# include <stdio.h>
# include <string.h>
# include <limits.h>

int strdcmp(char* s1, char* s2)
{
	int l1 = strlen(s1), l2 = strlen(s2);
	if (l1 < l2) return -1;
	if (l1 > l2) return 1;
	while ((*s1) == (*s2) && (*s1) != '\0'){
		s1++;
		s2++;
		}
	if ((*s1) < (*s2)) return -1;
	if ((*s1) > (*s2)) return 1;
	return 0;
}

int readint()
{
	char buff[100], int_max[100];
	sprintf(int_max, "%d", INT_MAX);
	scanf("%s", buff);
	if (strdcmp(buff, int_max) == 1) return -INT_MAX;
	return atoi(buff);
}

int main()
{
	int n = readint();
	
	printf("%d\n",n);

	return 0;
}

