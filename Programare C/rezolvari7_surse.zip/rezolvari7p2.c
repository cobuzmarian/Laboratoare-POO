/*
 * Problema 2
 */

#include <stdio.h>

int* get_max(int n, int *v) {
	if (n == 0)
		return NULL;
	int i;
	int max = *v, *pmax = v; //max retine valoarea lui v[0], iar pmax retine un pointer la inceputul vectorului
	for(i = 1; i < n; i++) {
		v++;
		if (*v > max) {
			max = *v;
			pmax = v;
			}
		}
	return pmax;
}

int main(){
	int n, v[100], i;

	//printf("n=");
	scanf("%d", &n);
	for(i = 0; i < n; i++)
		scanf("%d", &v[i]);

	int* poz = get_max(n, v);

	if (poz != NULL)  printf("%p\n%d\n", poz, *poz);	
	else printf("Vectorul are 0 elemente.\n"); //daca am incerca sa accesam poz, am primi Segmentation fault pentru ca poz este NULL in acest caz

	return 0;
}
