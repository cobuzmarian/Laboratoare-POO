/*
 * Problema 3
 */

#include <stdio.h>

void count(int n, int *v, int *zero, int *poz, int *neg){
	int i;
	*zero = *poz = *neg = 0;
	for(i = 0; i < n; i++)
		if (v[i] == 0) 
			(*zero)++;
		else 
			if (v[i] < 0)
				(*neg)++;
			else
				(*poz)++;
}

int main(){
	
	int v[100], i, n;
	int po = 0, ne = 0, ze = 0;	

	//printf("n=");
	scanf("%d", &n);
	for(i = 0; i < n; i++)
		scanf("%d", &v[i]);
	count(n, v, &ze, &po, &ne);
	printf("zero : %d\npoz : %d\nneg : %d\n", ze, po, ne);
	return 0;
}
