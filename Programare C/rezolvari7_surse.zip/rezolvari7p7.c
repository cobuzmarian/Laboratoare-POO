/*
 * Problema 7
 */

# include <stdio.h>
# include <string.h>

char* next(char* from, char* word)
{
	//pas 1: sarim peste caracterele care sunt diferite de '\0' sau de litere mici
	while ((*from) != '\0' && ((*from) < 'a' || (*from) > 'z')) from++;

	//daca nu mai sunt litere in from
	if ((*from) == '\0') return NULL;
	
	//pas 2: sarim peste litere
	char *p = from;
	while ((*p) != '\0' && (*p) >= 'a' && (*p) <= 'z') p++;

	//pas 3: copiem in word (p-from) caractere
	strncpy(word, from, p - from);
	word[p - from] = '\0';

	return p;
}

int main()
{
	char buff[100], *p, cuv[100];

	gets(buff);

	for (p = next(buff, cuv); p != NULL; p = next(p, cuv))
		printf("%s ", cuv);

	printf("\n");

	return 0;
}
