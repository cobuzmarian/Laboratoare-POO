/*
 * Problema 8
 */

# include <stdio.h>
# include <limits.h>
# include <stdlib.h>
# include <math.h>

# define EPS 1e-5

void panta(int x1, int y1, int x2, int y2, float *m, float *n)
{
	if (x1 == x2){
		*m = INT_MAX;
		*n = 0;
		return;
	}

	if (x2 < x1){
		panta(x2, y2, x1, y1, m, n);
		return;
	}

	*m = ((float)(y2 - y1)) / (x2 - x1);
	*n = y1 - (*m) * x1;
}

int main()
{
	int x1, x2, y1, y2, xverif, yverif;
	float m1, m2, n1, n2;

	//printf("Primul punct: ");
	scanf("%d%d", &x1, &y1);

	//printf("Al doilea punct: ");
	scanf("%d%d", &x2, &y2);

	//printf("Punctul de verificare: ");
	scanf("%d%d", &xverif, &yverif);

	panta(x1, y1, x2, y2, &m1, &n1);
	panta(x1, y1, xverif, yverif, &m2, &n2);

	if (abs(m1 - m2) <= EPS)
		printf("DA\n");
	else
		printf("NU\n");

	return 0;
}

