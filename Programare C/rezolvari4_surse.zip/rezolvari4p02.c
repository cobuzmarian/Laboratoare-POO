/**
 * Problema 2
 */
 
# include <stdio.h>

int main()
{
        int v[100], n, i, np, nn, sp, sn;

        printf("n = ");
        scanf("%d", &n);
        for (i = 0; i < n; i++) {
                printf("v[%d] = ", i);
                scanf("%d", &v[i]);
        }

        nn = np = 0; // numarul de numere negative / pozitive
        sn = sp = 0; // suma numerelor negative / pozitive

        for (i = 0; i < n; i++)
                if (v[i] < 0) {
                        nn++;
                        sn += v[i];
                }
                else if (v[i] > 0) {
                        np++;
                        sp += v[i];
                }

        if (np == 0)
                printf("MP = nu se poate calcula\n");
        else
                printf("MP = %.2f\n", (float)sp / np);

        if (nn == 0)
                printf("MN = nu se poate calcula\n");
        else
                printf("MN = %.2f\n", (float)sn / nn);
                
        //fflush(stdin); getchar();

        return 0;
}
