/**
 * Problema 4
 */

# include <stdio.h>

int main()
{
        int n, m, p, q, A[100][100], B[100][100], i, j, k;
        int C[100][100] = {0}; // toate valorile initializate la 0

        printf("m = "); 
        scanf("%d", &m);
        printf("n = ");
        scanf("%d", &n);
        
        for (i = 0; i < m; i++)
                for (j = 0; j < n; j++)
                        scanf("%d", &A[i][j]);

        printf("p = ");
        scanf("%d", &p);
        printf("q = ");
        scanf("%d", &q);
        for (i = 0; i < p; i++)
                for (j = 0; j < q; j++)
                        scanf("%d", &B[i][j]);

        if (n != p) {
                printf("nu se poate efectua A * B"); // afisam mesaj
                return 0; // iesim din program
        }

        for (i = 0; i < m; i++)
                for (j = 0; j < q; j++) 
                        for (k = 0; k < n; k++)
                                C[i][j] += A[i][k] * B[k][j];

        printf("%d %d\n", m, q);
        for (i = 0; i < m; i++) {
                for (j = 0; j < q; j++)
                        printf("%d ", C[i][j]);
                printf("\n");
        }

        //fflush(stdin); getchar();

        return 0;
}
