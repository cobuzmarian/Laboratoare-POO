/**
 * Problema 5
 */

# include <stdio.h>

int main()
{
        int n, m, i, j, k, A[100], B[100], C[100];

        //printf("n = ");
        scanf("%d", &n);
        //printf("m = ");
        scanf("%d", &m);        
        for (i = 0; i < n; i++) {
                //printf("A[%d] = ", i);
                scanf("%d", &A[i]);
        }

        for (i = 0; i < m; i++) {
                //printf("B[%d] = ", i);
                scanf("%d", &B[i]);
        }

        k = 0; // incepem sa construim noul vector
        i = 0;
        j = 0;
        while (i < n && j < m)
                if (A[i] < B[j]) { // daca elementul curent din A este mai mic
                        C[k] = A[i];
                        i++; // avansam in A
                        k++;
                }
                else {
                        C[k] = B[j];
                        j++; // avansam in B
                        k++;
                }
        // la sfarsit adaugam elementele ramase in A sau in B
        // tot timpul se va intra in cel mult unul din blocurile while
        while (i < n) {
                C[k] = A[i];
                i++;
                k++;
        }
        while (j < m) {
                C[k] = B[j];
                j++;
                k++;
        }

        for (i = 0; i < n + m; i++)
                printf("%d ", C[i]);
        printf("\n");

        //fflush(stdin); getchar();
        
        return 0;
}
