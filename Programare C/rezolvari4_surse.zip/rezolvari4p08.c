/**
 * Problema 8
 */
 
#include <stdio.h>

int main(){
    int n, v[100], s[100], i, max, pmax, sum;
    //vectorul s este vector asociat lui v si se construieste dupa relatia s[i] = sum(v[j]), j = 0:i
    
    //printf("%d", n);
    scanf("%d", &n);

    for(i = 0; i < n; i++)
          scanf("%d", &v[i]);
          
    s[0] = v[0];
    max = s[0];
    pmax = 0;
    for(i = 1; i < n; i++) {
	  //calculam s[i], care observam ca este egal cu s[i-1] adunat cu valoarea curenta v[i]
          s[i] = s[i - 1] + v[i];
	  // si ii retinem pozitia daca valoarea sa este maxima
          if (s[i] > max) {
             max = s[i];
             pmax = i;
             }
          }
                 
    //stim acum ca secventa noastra de suma maxima se termina pe pozitia pmax
    //si determinam pozitia de inceput (i) a secventei
    i = pmax;
    sum = 0;
    do {
       sum += v[i];
       i--;
    }while(sum != max);
    
    i++;
    
    //afisarea solutiei
    for(; i <= pmax; i++)
          printf("%d ", v[i]);
    
    //fflush(stdin); getchar();
    
    return 0;
}
