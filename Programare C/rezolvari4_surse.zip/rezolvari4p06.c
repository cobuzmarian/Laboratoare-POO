/**
 * Problema 6
 */

# include <stdio.h>

int main()
{
        int n, A[100][100], B[100][100], i, j;

        printf("n = ");
        scanf("%d", &n);
        for (i = 0; i < n; i++)
                for (j = 0; j < n; j++)
                        scanf("%d", &A[i][j]);

        for (j = 1; j < n; j++){
                for (i = n - j; i < n; i++)
                        printf("%d ", A[i][j]);
                //printf("\n");
        }

        printf("\n");
        
        //fflush(stdin); getchar();

        return 0;
}
