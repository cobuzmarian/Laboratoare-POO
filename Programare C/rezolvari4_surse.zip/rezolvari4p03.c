/**
 * Problema 3
 */

# include <stdio.h>
# include <limits.h>

int main()
{
        int a[100][100], n, m, i, j, max, min;

        printf("m = ");
        scanf("%d", &m);
        printf("n = ");
        scanf("%d", &n);
        for (i = 0; i < m; i++)
                for (j = 0; j < n; j++) {
                        printf("a[%d][%d] = ", i, j);
                        scanf("%d", &a[i][j]);
                }

        min = INT_MAX;
        for (i = 0; i < m; i++) {
                max = a[i][0];  // initializam maximul cu prima valoare de pe linia i
                for (j = 1; j < n; j++)
                        if (a[i][j] > max)
                                max = a[i][j];
                if (min > max)
                        min = max;
        }

        printf(/*"Punct in sa = */"%d\n", min);
        
        //fflush(stdin); getchar();

        return 0;
}
