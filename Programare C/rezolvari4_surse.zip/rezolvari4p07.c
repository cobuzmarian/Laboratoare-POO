/**
 * Problema 7
 */

# include <stdio.h>

int main()
{
        int V[100], n, i, max, maxstart, start;

        printf("n = ");
        scanf("%d", &n);
        for (i = 0; i < n; i++) {
                //printf("V[%d] = ", i);
                scanf("%d", &V[i]);
        }

        max = 0; maxstart = -1;
        start = 0; // pozitia de start
        for (i = 1; i < n; i++)
                if (V[i - 1] > V[i]) {        // daca secventa nu mai e crescatoare
                        if (i - start > max) {       // verificam daca avem un nou maxim
                                max = i - start;
                                maxstart = start;
                        }
                        start = i;
                }

        for (i = maxstart; i < maxstart + max; i++)
                printf("%d ", V[i]);
        printf("\n");
        
        //fflush(stdin); getchar();

        return 0;
}
