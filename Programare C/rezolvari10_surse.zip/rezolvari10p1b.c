/*
 * Problema 1B
 *
 */

#include <stdio.h>
#include <stdlib.h>

struct multime {
	int n;
	unsigned char *a;
};

void init(struct multime *m, int n)
{
	int i, size = n / (8 * sizeof(unsigned char));
	m->n = n;
	
	if (n % (8 * sizeof(unsigned char)) != 0)
		size++;
	m->a = (unsigned char *) malloc (size * sizeof(unsigned char));

	for (i = 0; i < size; i++)
		m->a[i] = 0;
}

void add(struct multime *m, int x)
{
	int idx, cnt;
	idx = x / (8 * sizeof(unsigned char));
	cnt = x % (8 * sizeof(unsigned char));
	m->a[idx] = m->a[idx] | (1 << cnt);
}

void del(struct multime *m, int x)
{                                 
	int idx, cnt;
	idx = x / (8 * sizeof(unsigned char));
	cnt = x % (8 * sizeof(unsigned char)); 
	m->a[idx] = m->a[idx] & ~(1 << cnt);
}

int contains(struct multime *m, int x)
{   
    int idx, cnt;
	idx = x / (8 * sizeof(unsigned char));
	cnt = x % (8 * sizeof(unsigned char)); 
	return m->a[idx] & (1 << cnt);
}

void print(struct multime *m)
{
	int i;
	printf("{ ");
	for (i = 0; i < m->n; i++)
		if (contains(m, i))
			printf("%d ", i);
	printf("}\n");
}

void delete(struct multime *m)
{
	free(m->a);
}

int main()
{
	struct multime m;
	init(&m, 200);
	add(&m, 3);
	add(&m, 35);
	add(&m, 112);
	add(&m, 199);
	print(&m);
	del(&m, 35);
	del(&m, 199);
	print(&m);
	delete(&m);
	return 0;
}
