/*
 * Problema 4
 *
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct MATRICE {
	int n, m;
	int **a;
} MATRICE;

MATRICE *creaza_MATRICE(int n, int m)
{
	int i;
	MATRICE *mat;

	mat = (MATRICE*) malloc (sizeof(MATRICE)); // alocam memorie pentru structura

	mat->n = n;
	mat->m = m;  
	
	// si pentru matricea propriu-zisa
	mat->a = (int**) malloc (n * sizeof(int*)); // pentru pointerii la linii
	for (i = 0; i < n; i++)
		mat->a[i] = (int*) malloc (m * sizeof(int)); // si pentru elementele de pe fiecare linie
	return mat;
}

void sterge_MATRICE(MATRICE *a)
{
	int i;
	for (i = 0; i < a->n; i++)
		free(a->a[i]);
	free(a->a);
}

MATRICE *citeste_MATRICE(MATRICE *a)
{
	int i, j;
	for (i = 0; i < a->n; i++) 
		for (j = 0; j < a->m; j++) {
			printf("a[%d][%d] = ", i, j);
			scanf("%d", &a->a[i][j]);
		}
    return a;
}

void scrie_MATRICE(MATRICE *a)
{
	int i, j;
	for (i = 0; i < a->n; i++) {
		for (j = 0; j < a->m; j++)
			printf("%d ", a->a[i][j]);
		printf("\n");
	}
	printf("\n");
}

MATRICE *aduna_MATRICE(MATRICE *a, MATRICE *b)
{
	MATRICE *s;
	int i, j;

	if (a->n != b->n || a->m != b->m)
		return NULL;

	s = creaza_MATRICE(a->n, a->m);
	for (i = 0; i < a->n; i++)
		for (j = 0; j < a->m; j++)
			s->a[i][j] = a->a[i][j] + b->a[i][j];

	return s;
}

MATRICE *inmulteste_MATRICE(MATRICE *a, MATRICE *b)
{
	MATRICE *s;
	int i, j, k;

	if (a->m != b->n)
		return NULL;

	s = creaza_MATRICE(a->n, b->m);
	for (i = 0; i < s->n; i++)
		for (j = 0; j < s->m; j++) {
			s->a[i][j] = 0;
			for (k = 0; k < a->m; k++)
				s->a[i][j] += a->a[i][k] * b->a[k][j];
		}

	return s;
}

int main()
{
	int n, m;
	MATRICE *a, *b, *s, *p;
	printf("Introduceti dimensiunea pentru prima matrice.\n");
	printf("n = ");
	scanf("%d", &n);
	printf("m = ");
	scanf("%d", &m);
	a = creaza_MATRICE(n, m); 
	citeste_MATRICE(a);

	printf("Introduceti dimensiunea pentru cea de-a 2-a matrice.\n");
	printf("n = ");
	scanf("%d", &n);
	printf("m = ");
	scanf("%d", &m); 
	b = creaza_MATRICE(n, m);
	citeste_MATRICE(b);

	s = aduna_MATRICE(a, b);
	if (s == NULL)
		printf("Nu s-a putut calcula suma.\n");
	else {
		printf("Suma lor este:\n");
		scrie_MATRICE(s);
	}

	p = inmulteste_MATRICE(a, b);
	if (p == NULL)
		printf("Nu s-a putut calcula produsul.\n");
	else {
		printf("Produsul lor este:\n");
		scrie_MATRICE(p);
	}

	sterge_MATRICE(a);
	sterge_MATRICE(b);
	sterge_MATRICE(s);
	sterge_MATRICE(p);

	return 0;
}
