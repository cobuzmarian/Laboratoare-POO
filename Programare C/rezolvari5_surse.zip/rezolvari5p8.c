/**
 * Problema 8
 */
 
#include <stdio.h>

int min(int a, int b){
	return a > b ? b : a;
}

int max(int a, int b){
	return a > b ? a : b;
}

int lungime_intersectie_segmente(int a_stga, int a_drta, int b_stga, int b_drta)
{
	int c_stga, c_drta;
	c_stga=max(a_stga, b_stga);
	c_drta=min(a_drta, b_drta);
	if (c_stga > c_drta) return 0;
	return c_drta-c_stga;
}	

int arie_intersectie(int x11, int y11, int x12, int y12, int x21, int y21, int x22, int y22)
{
	return lungime_intersectie_segmente(x11, x12, x21, x22)*lungime_intersectie_segmente(y12, y11, y22, y21);
}

int main()
{
	int x11, y11, x12, y12, x21, y21, x22, y22;
	scanf("%d%d%d%d", &x11, &y11, &x12, &y12);
	scanf("%d%d%d%d", &x21, &y21, &x22, &y22);
	printf("%d\n", arie_intersectie(x11, y11, x12, y12, x21, y21, x22, y22));
	return 0;
}
