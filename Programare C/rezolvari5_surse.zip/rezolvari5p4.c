/**
 * Problema 4
 */
 
#include<stdio.h>

int cmmdc (int a, int b)
{
	while (a != b)
	{
		if (a > b)
			a = a - b;
		if (b > a)
			b = b - a;
	}
	return a;
}


int cmmmc (int a, int b)
{
	return (a * b / cmmdc (a, b));
}


int main ()
{
	int mc, x1, y1, x2, y2;
	scanf ("%d%d%d%d", &x1, &y1, &x2, &y2);
	if (y1 != y2)
	{
		mc = cmmmc (y1, y2);
		x1 = x1 * (mc / y1);
		x2 = x2 * (mc / y2);
		y1 = y2 = mc;
	}
	printf ("%d/%d\n%d/%d\n", x1, y1, x2, y2);
	fflush (stdin);
	getchar ();
}
