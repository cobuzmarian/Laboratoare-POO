/**
 * Problema 2
 */
 
#include <stdio.h>

int cifra(int x, int c)
{
	while (x > 0) {
		if(x % 10 == c)
			return 1;
		x = x / 10;
	}
	return 0;
}


int main()
{
	int n,  c;
	scanf("%d%d", &n, &c);
	if(cifra(n, c))
		printf("DA\n");
	else
		printf("NU\n");
	return 0;
}
