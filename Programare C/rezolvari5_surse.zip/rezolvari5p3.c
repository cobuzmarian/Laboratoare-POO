/**
 * Problema 3
 */
 
#include <stdio.h>
#include <math.h>

int prim(int n)
{
	int i;
	for (i = 2; i <= sqrt(n); i++)
		if (n % i == 0)
			return 0; // daca are un divizor nu e prim
	return 1; // daca am ajuns aici, nu s-a gasit niciun divizor
}

int main()
{
	int n, i;
	printf("n = ");
	scanf("%d", &n);

	for (i = 1; i < n / 2; i++)
		if (prim(i) && prim(n - i))
			printf("%d+%d\n", i, n - i);
	
	return 0;
}
