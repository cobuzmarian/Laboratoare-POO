/**
 * Problema 7
 */
 
#include <stdio.h>

int transforma(int n)
{
	int nr, i, cif, c[10] = {0}; // c[i] = de cate ori apare cifra i in numar
	while (n > 0) {
		cif = n % 10;
		c[cif]++;
		n = n / 10;
	}
	nr = 0; // noul numar
	if (c[0] != 0) { // contine 0  => descrescator
		for (cif = 9; cif >= 0; cif--) // pt fiecare cifra
			for (i = 0; i < c[cif]; i++) // o adaugam la nr de cate ori apare
				nr = nr * 10 + cif;
	}
	else { // crescator
		for (cif = 1; cif <= 9; cif++)
			for (i = 0; i < c[cif]; i++)
				nr = nr * 10 + cif;
	}
    return nr;
}

int main()
{
	int n;
	scanf("%d", &n);
	printf("%d\n", transforma(n));
	return 0;
}
