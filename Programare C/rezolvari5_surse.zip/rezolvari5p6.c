/**
 * Problema 6
 */
 
#include <stdio.h>
#include <math.h>

float dist(int x1, int y1, int x2, int y2)
{
	float sqrd = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
	return sqrt(sqrd);
}

int main()
{
	int X[100], Y[100], n, i, j, imax, jmax;
	float dmax, dij;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
		scanf("%d%d", &X[i], &Y[i]);

	dmax = 0;
	for (i = 0; i < n; i++)
		for (j = 0; j < n; j++) {
			dij = dist(X[i], Y[i], X[j], Y[j]);
			if (dij > dmax) {
				dmax = dij;
				imax = i;
				jmax = j;
			}
		}

	printf("[(%d, %d);(%d, %d)] formeaza distanta maxima %f\n", X[imax], Y[imax], X[jmax], Y[jmax], dmax);

	return 0;
}
