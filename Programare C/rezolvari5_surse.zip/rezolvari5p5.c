/**
 * Problema 5
 */
 
#include <stdio.h>

int factorial(int n)
{
	int p = 1, i;
	for (i = 1; i <= n; i++)
		p *= i; // p = p * i
	return p;
}

double putere(double x, int n)
{
	double p = 1;
	int i;
	for (i = 1; i <= n; i++)
		p *= x; // p = p * x
	return p;
}

double taylor(double x, int n)
{
	double t = 1;
	int i;
	for (i = 1; i <= n; i++)
		t += putere(x, i) / factorial(i);
	return t;
}

int main()
{
	float x;
	int n;
	printf("x = ");
	scanf("%f", &x);
	printf("n = ");
	scanf("%d", &n);
	printf("e ^ %.3f = %.3f\n", x, taylor(x, n));
	return 0;
}
