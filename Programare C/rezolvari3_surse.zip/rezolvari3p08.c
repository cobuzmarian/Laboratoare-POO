/**
 * Problema 8
 *
 */

// Pentru functiile scanf() si printf()
#include <stdio.h>
// Pentru functiile fabs() si sqrt()
#include <math.h>

int main ()
{
	float x, r1, r2, EPS = 0.001;
	int i;

	scanf("%f", &x);

	r1 = r2 = x / 2 ;
	do
	{
		r1 = r2;
		r2 = ( r1 + x/r1 ) / 2;
	} while ( fabs( r1 - r2 ) > EPS );

	printf("rad(%2.0f)  =  %.3f  |  %.3f \n", x, r2, sqrt(x));

	for(i = 1; i <= 20; i++)
		printf("rad(%d) = %.3f\n", 2 * i, sqrt(2 * i));

	return 0;
}
//mai multe detalii despre functia sqrt() gasiti accesand http://www.cplusplus.com/reference/clibrary/cmath/sqrt/


