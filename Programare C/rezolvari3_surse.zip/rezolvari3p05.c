/**
 * Problema 5
 *
 */

// Pentru functiile printf() si scanf()
#include <stdio.h>

int main()
{
	int i, j, p, k;

	scanf( "%d", &p );
	for( i = 1; i < p - 1; i++ )
		for( j = i; j < p - i; j++ ) {
			k = p - i - j;
			// verificam daca cele 3 numere pot forma laturile unui triunghi.
			if ( k >= j && k <= i + j && i <= k + j && j <= k + i )
				printf( "%d %d %d\n", i, j, k );
		}

	return 0;
}


