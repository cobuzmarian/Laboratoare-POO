/**
 * Problema 1
 *
 */

// Pentru functia printf()
#include <stdio.h>

int main()
{
	int i;

	for ( i = 32; i < 127; i++ )
		if ( i % 10 == 1 )
			printf("%c = %d\n", i, i );
		else
			printf("%c = %d ", i, i );
	return 0;
}


