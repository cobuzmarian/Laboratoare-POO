/**
 * Problema 6
 *
 */

// Pentru printf() si scanf()
#include <stdio.h>

int main ()
{
	int n, m, i, c, nf, mf, nmf;

	scanf ("%d%d", &n, &m);
	
	//metoda 1: folosirea relatiei de recurenta
	c = 1; // C(n,0)
	for (i = 1; i <= m; i++)
		c = c * (n - i + 1) / i;
	printf ("C(%d, %d) = %d\n", n, m, c);

	//metoda 2: folosind relatia de calcul
	for (nf = 1, i = 1; i <= n; i++) nf *= i;     //calculul lui n!
	for (mf = 1, i = 1; i <= m; i++) mf *= i;     //calculul lui m!
	for (nmf = 1, i = 1; i <= n - m; i++) nmf *= i; //calculul lui (n - m)!

	printf ("C(%d, %d) = %d\n", n, m, nf / (mf * nmf));

	return 0;
}

