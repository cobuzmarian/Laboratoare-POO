/**
 * Problema 9
 *
 */

// Pentru printf() si scanf()
#include <stdio.h>
// Pentru sqrt(x)
#include <math.h>

int main ()
{
	int n, i;
	int p = 1, q = 1; // cu p si q generez sirul lui fibonacci
	int prim, d, rad, aux;

	scanf ("%d", &n);
	if (n <= 3) { // primii 3 termeni sunt 0,1,1
		printf ("Nu exista numere prime\n");
		return 0;
	}
	printf ("Numerele prime din sirul Fibonacci sunt: ");
	for (i = 4; i <= n; i++) {
		aux = p;
		p = q;
		q = aux + q; // calculam in q termenii sirului Fib. , tinand cont ca ultimii doi termeni sunt p si q

		if (q == 2)
			printf ("%d ", q);
		else {
			// daca restul impartirii lui q la 2 este 0, atunci q nu poate fi numar prim
			prim = q % 2 == 0 ? 0 : 1;
			//luam partea intreaga a radicalului
			rad = (int)(sqrt(q));
			d = 3;
			while (prim && d <= rad) {
				if (q % d == 0)
					prim = 0;
				d += 2;
			}
			if (prim)
				printf ("%d ", q);
		}
	}
	printf("\n");
	return 0;
}

