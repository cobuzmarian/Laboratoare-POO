/**
 * Problema 4
 *
 */

// Pentru functiile printf() si scanf()
#include <stdio.h>

int main()
{
	int a, b, s, aux;
	// se citeste un numar
	scanf("%d", &a);
	// se verifica daca numarul este egal cu 0
	if (a == 0)
		return 0;
	do
	{
		//se citeste un alt numar
		scanf("%d", &b);
		// se calculeaza suma cifrelor primului numar din pereche, adica suma cifrelor lui a
		aux = a;
		for ( s = 0; aux > 0; aux /= 10)
			s += aux % 10;
		// se verifica conditia
		if (b == a % s)
			printf("%d %% %d = %d \n", a, s, b);
		// se actualizeaza valoarea lui a
		a = b;   
	} while (a != 0);
	return 0;
}


