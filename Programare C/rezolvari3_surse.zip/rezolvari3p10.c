/**
 * Problema 10
 *
 */

#include <stdio.h>

int main ()
{
	int n, limit = 10, nr_cf = 1;
	int s = 0; // suma cifrelor

	scanf ("%d", &n);
	//intuitiv: 	intre 0 si 9 exista 10 numere de 1 cifra
	//		intre 10 si 99 exista 90 de numere de 2 cifre
	//comparam pe rand numarul n cu 10^1, 10^2 etc. pana cand n il depaseste pe limit (o putere a lui 10)
	while (n >= limit) {
		//actualizam suma
		s += nr_cf * (limit - limit/10);
		//odata cu cresterea limitei crestem si numarul de cifre
		nr_cf++;
		//actualizam limita prin inmultirea cu 10
		limit *= 10;
	}
	limit /= 10;
	//se va mai adauga la suma diferenta de cifre dintre n ultima limita
	s += nr_cf * (n - limit + 1);

	printf ("%d\n", s);
	return 0;
}

