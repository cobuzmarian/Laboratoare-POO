/**
 * Problema 3
 *
 */

// Pentru functiile scanf() si printf()
#include <stdio.h>

int main ()
{
	float x, sx = 0;
	double y, sy = 0;
	int n, i;

	printf ("n = "); scanf ("%d", &n);
	printf ("x = "); scanf ("%f", &x);
	printf ("y = "); scanf ("%lf", &y);

	for (i = 0; i < n; i++) {
		// reactualizam sumele partiale sx si sy
		sx += x;
		sy += y;
		//testam daca am parcurs n/10 termeni
		if (i % (n / 10) == 0) printf("%f %e\n%lf %e\n\n", sx, sx, sy, sy);
	}
	printf("%f %e\n%lf %e\n", sx, sx, sy, sy);

	return 0;
}


