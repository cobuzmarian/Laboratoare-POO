/**
 * Problema 7
 *
 */

// Pentru functiile printf() si scanf()
#include <stdio.h>
// Pentru functia pow()
#include <math.h>

int main() 
{
	float x, s1 = 0, s2 = 0, t = 1, eps = 0.0001;
	int n, i;
	scanf("%f %d", &x, &n);
	for ( i = 0; i < n; i++)               /* Ca suma a unui numar dat de termeni */
	{
		s1 += t;
		t = t * x / (i + 1);
	}
	
	t = 1;
	for ( i = 0; t > eps; i++)           /* Ca suma a termenilor mai mari decat un epsilon dat*/
	{
		s2 += t;
		t = t * x / (i + 1);
	}
	
	printf("%f     %f    %f     %f\n", s1, s2, exp(x), pow(2.718, x));
	return 0;
}
//pentru mai multe detalii despre functia pow() accesati http://www.cplusplus.com/reference/clibrary/cmath/pow/
