/**
 * Problema 2
 *
 */

//Pentru functiile scanf() si printf()
# include <stdio.h>

int main()
{
	int i, n, m;

	scanf("%d%d", &n, &m);

	for (i = 1; i <= n; i++){
		printf("%6d", i);
		// conditie de test pentru trecerea la linie noua
		if (i % m == 0) 
			printf("\n");
		// conditie de test pentru intreruperea afisarii
		if (i % (24 * m) == 0){
			fflush(stdin);
			getchar();
		}
	}

	return 0;
}

