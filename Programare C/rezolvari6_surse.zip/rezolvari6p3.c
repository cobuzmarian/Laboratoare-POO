/*
 * Problema 3
 */
 
#include <stdio.h>
#include <math.h>

void unghiuri(float l[], float u[])
{                
	u[0] = acos((-l[0] * l[0] + l[1] * l[1] + l[2] * l[2]) / (2 * l[1] * l[2])) * (180 / M_PI);
	u[1] = acos(( l[0] * l[0] - l[1] * l[1] + l[2] * l[2]) / (2 * l[0] * l[2])) * (180 / M_PI);
	u[2] = acos(( l[0] * l[0] + l[1] * l[1] - l[2] * l[2]) / (2 * l[0] * l[1])) * (180 / M_PI);
}

int main()
{
	float l[3], u[3];
	scanf("%f%f%f", &l[0], &l[1], &l[2]);
	unghiuri(l, u);
	printf("%.2f %.2f %.2f\n", u[0], u[1], u[2]);
	return 0;
}                                                        
 
