/*
 * Problema 5
 */
 
#include <stdio.h>
#include <string.h>

int mystrcmp(char s1[], char s2[])
{
	int n1, n2, i;
	n1 = strlen(s1);
	n2 = strlen(s2);

	for (i = 0; i < n1 && i < n2; i++) // mergem pana la min(n1, n2)
		if (s1[i] > s2[i])             // si cautam elemente diferite
			return 1;
		else if (s1[i] < s2[i])
			return -1;

	if (n1 > n2)
		return 1;
	if (n1 < n2)
		return -1;
	return 0;
}

int main()
{
	char s1[100], s2[100];
	scanf("%s", s1);
	scanf("%s", s2);

	printf("%d\n", mystrcmp(s1, s2));

	return 0;
}
 
