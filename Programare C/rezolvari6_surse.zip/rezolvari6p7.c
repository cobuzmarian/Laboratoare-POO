/*
 * Problema 7
 */
 
#include <stdio.h>

void spirala(int A[][100], int m, int n, int V[])
{
	int pi, pj, i, j, dir = 0, newi, newj, nr = 0,
		limup = 0, limdown = m - 1, limleft = 0, limright = n - 1;
	int px[4] = {0, 1, 0, -1}, py[4] = {1, 0, -1, 0};
	i = 0; j = 0; // pozitia initiala

	V[0] = A[0][0]; nr++;
	while (nr < m * n) {
		newi = i + px[dir];
		newj = j + py[dir];
		if (!(limup <= newi && newi <= limdown && limleft <= newj && newj <= limright)) {
			switch (dir) {
            	case 0: if (limup < limdown) limup++; break;
				case 2: if (limdown > limup) limdown--; break;
				case 1: if (limright > limleft) limright--; break;
				case 3: if (limleft < limright) limleft++; break;
			}
			dir = (dir + 1) % 4;
		}
		i = i + px[dir];    
		j = j + py[dir];
		V[nr] = A[i][j];
		nr++; 
	}
}

void afisare(int V[], int dim)
{
	int i;
	for (i = 0; i < dim; i++)
		printf("%d ", V[i]);
	printf("\n");
}

int main()
{
	int A[100][100], m, n, V[10000], i, j;
	scanf("%d%d", &m, &n);
	for (i = 0; i < m; i++) {
		//printf("Linia %d : ", i);
		for (j = 0; j < n; j++)
			scanf("%d", &A[i][j]);
	}
	spirala(A, m, n, V);
	afisare(V, m * n);
	return 0;
}
 
