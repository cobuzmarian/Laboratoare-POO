/*
 * Problema 6
 */
 
#include <stdio.h>

void transform(int v[], int n, int x)
{
	int st = 0, dr = n - 1, aux;
	while (st < dr) {
		while (v[st] < x && st < n) // cat timp respecta ordinea avansam la stanga
			st++;
		while (x <= v[dr] && dr > 0) // si la dreapta
			dr--;
		if (st < dr) { 	// am gasit o pereche inversata
			aux = v[st];
			v[st] = v[dr];
			v[dr] = aux;
		}
	}
}

int main()
{
	int v[100], n, x, i;

	//printf("n = "); 
	scanf("%d", &n);                   
	//printf("x = ");
	scanf("%d", &x);
	//printf("Introduceti elementele: ");
	for (i = 0; i < n; i++)
		scanf("%d", &v[i]);

	transform(v, n, x);

	for (i = 0; i < n; i++)
		printf("%d ", v[i]);

	printf("\n");

	return 0;
}
 
