/*
 * Problema 2
 */

#include <stdio.h>

void BubbleSort(int x[], int dim) {
	int i, j, aux;
	for(i = 0; i < dim - 1; i++)
		for(j = i + 1; j < dim; j++)
			if (x[i] > x[j]) {
				aux = x[i];
				x[i] = x[j];
				x[j] = aux;
			}
}

int main(){
	//printf("n=");
	int n, i, v[100];
	scanf("%d", &n);
	for(i = 0; i < n; i++)
		scanf("%d", &v[i]);
	BubbleSort(v, n);
	for(i = 0; i < n; i++)
		printf("%d ", v[i]);
	printf("\n");
	return 0;	
}
