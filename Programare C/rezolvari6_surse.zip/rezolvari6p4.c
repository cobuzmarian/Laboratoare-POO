/*
 * Problema 4
 */
 
#include <stdio.h>

int inters(int a[], int n, int b[], int m, int c[])
{
	int i, j, k, d = 0, ok;
	for (i = 0; i < n; i++)
		for (j = 0; j < m; j++) 
            		if (a[i] == b[j]) {
				// verificam daca nu a fost deja adaugat
				ok = 1;
				for (k = 0; k < d; k++)
					if (c[k] == a[i]) {
						ok = 0;
						break;
					}
				if (ok) {
					c[d] = a[i]; //adaugam in vector
					d++;		// crestem nr de elemente
				}
			}
	return d;
}


int main()
{
	int v1[100], v2[100], v3[100], n1, n2, n3, i;

	//printf("n1 = ");
	scanf("%d", &n1);
	//printf("Elementele v1: ");
	for (i = 0; i < n1; i++)
		scanf("%d", &v1[i]);
    
	//printf("n2 = ");
	scanf("%d", &n2);
	//printf("Elementele v2: ");
	for (i = 0; i < n2; i++)
		scanf("%d", &v2[i]);

	n3 = inters(v1, n1, v2, n2, v3); //inters returneaza dimensiunea lui v3

	printf("%d\n", n3);
 	for (i = 0; i < n3; i++)
		printf("%d ", v3[i]);
	printf("\n");

	return 0;
}
 
