/*
 * Problema 3
 *
 */

#include <stdio.h>
#include <string.h>

#define MAXN 1000

typedef struct {
	char nume[100];
	char prenume[100];
	float n_a, n_e, n_f;
} STUDENT;

int main(int argc, char *argv[])
{
	char buffer[1000];
	int i, n = 0, np = 0, nr_elevi;
	float max;
	STUDENT st[MAXN];
	FILE *f = fopen(argv[1], "r");
	fscanf(f, "%d", &nr_elevi);
	//while (fscanf(f, "%s%s%f%f", st[n].nume, st[n].prenume, &st[n].n_a, &st[n].n_e) == 4) {
	for(n = 0; n < nr_elevi; n++) {
		fscanf(f, "%s%s%f%f", st[n].nume, st[n].prenume, &st[n].n_a, &st[n].n_e);
		// calcul si afisare nota finala
		st[n].n_f = (st[n].n_a + 2 * st[n].n_e) / 3;
		printf("Nota finala %s %s: %.2f ", st[n].nume, st[n].prenume, st[n].n_f);
		// verificare promovat
		if (st[n].n_f >= 5 && st[n].n_a >= 5 && st[n].n_e >= 5) {
			np++;
			printf("promovat\n");
		}
		else 
			printf("nepromovat\n");
		// verificare nota maxima
		if (st[n].n_f > max)
			max = st[n].n_f;
		//n++;
	}
	printf("%d studenti promovati.\n%.2f%%(procent de promovabilitate)\n", np, np * 100.0 / n);
	printf("Nota maxima = %.2f. Studenti care au obtinut nota maxima:\n", max);
	for (i = 0; i < n; i++)
		if (st[i].n_f == max)
			printf("%s %s\n", st[i].nume, st[i].prenume);
	fclose(f);
	return 0;
}
