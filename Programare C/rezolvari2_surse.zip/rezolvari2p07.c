/*
 * Problema 7
 */

# include <stdio.h>

int main()
{
	int a, b, c, d, min, max;

	scanf ("%d%d%d%d", &a, &b, &c, &d);

	// Aflam mai intai maximul dintre "a" si "b" si il stocam in variabila
	//  "max", apoi verificam pe rand daca nu cumva "c" si "d" sunt mai mari
	//  si in caz afirmativ, actualizam valoarea pe care o consideram noi
	//  maxima.
	if (a>b)
		max = a;
	else
		max = b;
	if (c>max) max = c;
	if (d>max) max = d;

	// Pentru aflarea minimului se procedeaza analog.
	if (a<b)
		min = a;
	else
		min = b;
	if (c<min) min = c;
	if (d<min) min = d;

	// Afisarea concluziilor (Observatie: am afisat doua linii consecutive
	//  cu un singur apel de functie printf(), inserand la locul potrivit
	//  caracterul "\n", care are rolul de a trece pe linia urmatoare.
	printf("Minimul este: %d\nMaximul este: %d\n", min, max);

	// Nu uitati ca executia cu succes inseamna intoarcerea valorii 0 in
	//  main()!
	return 0;
}

