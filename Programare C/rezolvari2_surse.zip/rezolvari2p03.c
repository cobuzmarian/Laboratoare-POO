/*
 * Problema 3
 */

// Pentru a avea functiile printf() si scanf():
# include <stdio.h>
// Pentru a avea functiile sin() si cos(), si valoarea lui "pi":
# include <math.h>

int main()
{
	// Valoarea constantei "pi" este data - pana la o anumita precizie - in
	//  macrodefinitia M_PI din biblioteca <math.h>
	double x, PI = M_PI;

	// Pentru a afisa un tabel, vom afisa datele linie cu linie, avand grija
	//  ca ele sa fie aliniate unele sub altele astfel incat sa cream
	//  impresia vizuala a unui tabel. Aceeasi conventie o va respecta si
	//  capul de tabel.
	printf("   x     sin(x)   cos(x)\n" );
	for(x = 0; x <= 2 * PI; x = x + PI / 20) {
		// Pentru semnificatia specificatorilor de format, recapitulati
		//  din laborator/curs partea teoretica de la afisare.
		printf( "%+2.3lf   %+2.3lf   %+2.3lf\n", x, sin(x), cos(x));
	}

	// Pentru ca functia main() s-a incheiat cu succes:
	return 0;
}

