/*
 * Problema 4
 */

# include <stdio.h>

int main()
{
	float x, y;

	scanf("%f%f", &x, &y);

	// Verificam intai daca nu cummva punctul este pe una din axe:
	if (x == 0 || y == 0) {

		// Daca e pe axe, atunci afisam mesajul si am terminat:
		printf("Punct pe axe");

	} else {

		// In acest moment stim SIGUR ca nu este pe axe si verificam
		//  daca nu cumva este deasupra axei Ox 
		if (x > 0) {
			
			// Mai ramane de verificat pozitia in raport cu Oy
			if (y > 0)
				printf("Cadranul 1");
			else
				printf("Cadranul 4");

		} else {

			// In acest moment stim SIGUR ca nu este deasupra axei
			//  Ox si verifica pozitia in raport cu Oy
			if (y > 0)
				printf("Cadranul 2");
			else
				printf("Cadranul 3");
		
		}
	
	}

	// Incheierea cu succes a functiei main()
	return 0;
}

