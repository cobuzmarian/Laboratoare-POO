/* 
 * Problema 5
 */

#include <stdio.h>

int main()
{
	int a, b, c;

	// Nu uitati sa nu introduceti caractere suplimentare pe langa
	//  specificatorii de format in scanf()
	scanf("%d%d%d", &a, &b, &c);

	// Trei numere intregi pot forma laturile unui triunghi doar daca suma a
	//  ORICARE doua dintre ele este mai mare sau egala cu alt treilea
	//  (cazul de egalitate reprezinta un triunghi denaturat). Asta
	//  inseamna:
	//      (c + b >= a && a + c >= b && a + b >= c)
	//  sau daca negam expresia de mai sus se obtine conditia sa NU formeze
	//  triunghi:
	//      (a > b + c || b > a + c || c > a + b)
	//  De exemplu, am ales sa folosim a doua varianta:
	if (a > b + c || b > a + c || c > a + b)
		printf("NU");
	else
		printf("DA");

	return 0;
}
