/*
 * Problema 9 + 10
 */

// Pentru a avea functiile scanf() si printf()
#include <stdio.h>

int main()
{
	// Variabilele in care sa retinem ORA, MINUTUL si SECUNDA
	int h, m, s; 

	// Citim ora (si verificam ca a fost citita corect)
	if (scanf("%d", &h) != 1) {  

		// Exemplu de situatie in care functia main() ar putea sa
		//  introduca o valoare diferita de 0: caz de eroare, care poate
		//  fi interpretat la nevoie sau poate fi ignorat. In orice caz,
		//  se incheie executia programului.
		printf("Ora a fost introdusa eronat.\n");
		return 1; 

	}

	// Testam ora: s-a citit un intreg, dar este el corect?
	if (h < 0 || h > 23) { 

		// Intoarcem un alt cod de eroare (ce poate fi interpretat sau
		//  ignorat de un al program din exterior)
		printf("Ora trebuie sa fie in intervalul 0..23\n");
		return 11;

	}

	// Procedam analog pentru minute
	if (scanf("%d", &m) != 1) {

		// De data aceasta intoarcem un alt cod de eroare, pentru a face
		//  distinctie intre sursele diferite de erori.
		printf("Minutul a fost introdus eronat.\n");
		return 2; 

	}

	// Testam minutul: s-a citit un intreg, dar este el corect?
	if (m < 0 || m > 59) {
		printf("Minutul trebuie sa fie in intervalul 0..59\n");
		return 22;
	}

	// Procedam analog pentru secunde
	if ( scanf("%d", &s) != 1) {  
		printf("Secunda a fost introdusa eronat.\n");
		return 3;
	}

	// Testam secunda: s-a citit un intreg, dar este el corect?
	if (s < 0 || s > 59) {  
		printf("Secunda trebuie sa fie in intervalul 0..59\n");
		return 33; 
	}

	// Daca am ajuns aici, inseamna ca toate datele au fost citite corect
	//  (au fost introduse numere intregi in intervalele corect) si afisam
	//  ora in formatul HH:MM:SS (fiecare cifra pe doua pozitii):
	printf("%02d:%02d:%02d\n", h, m, s);

	return 0;
}

