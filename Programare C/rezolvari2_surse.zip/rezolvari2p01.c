/*
 * Problema 1
 */

// Pentru functiile pe care le vom folosi in program, trebuie sa
//  includem biblioteci suplimentare astfel:
//     1) pentru a putea folosi functia printf() vom include:
# include <stdio.h>
//     2) pentru a putea folosi functiile srand() si rand() vom include:
# include <stdlib.h>

int main()
{
	// Atentie!! In ANSI C, declaratiile de variabile nu se pot face in
	//  interiorul buclelor (de exemplu, la bulca "for").
	int i;

	// Trebuie sa initializam generatorul de numere aleatoare cu o valoare.
	// Am ales in acest exemplu ca acea valoare sa fie "0". De obicei, in
	//  practica se foloseste timpul local in secunde (ca sa fie diferit de
	//  la o rulare la alta)
	srand(0);

	for (i = 0; i < 5; i++) {

		// Pentru a trece pe linia urmatoare, afisam caracterul "\n",
		//  care se numeste "newline", din motive evidente. 
		// Observatie: functia printf() afiseaza valori, deci putem
		//  sa afisam efectiv rezultatul intors de apelul functiei 
		//  rand(), fara sa folosim variabile auxiliare.
		printf("%d %d %d\n", rand(), rand(), rand());

	}

	// Orice program care are functia main de tipul <int> si a carui
	//  executie se incheie fara erori trebuie sa intoarca valoarea "0",
	//  prin conventie. (motivul il veti afla mai tarziu la USO)
	return 0;
}

