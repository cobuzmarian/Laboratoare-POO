/*
 * Problema 2
 */

// Includem biblioteca <stdio.h> pentru a avea functiile scanf() si printf()
# include <stdio.h>

int main()
{
	float a, b, c;

	// Atentie! In stringurile de format pe care le primeste scanf() nu
	//  trebuie - in marea majoritate a cazurilor - sa introduceti altceva
	//  in afara de specificatorii de format (ca de exemplu, spatii). 
	// De asemenea, numele variabilelor ce vor fi citite trebuie precedat de
	//  caracterul "&" - numit si "ampersand".
	scanf("%e%f%g", &a, &b, &c);

	// Prin comparatie, stringul de format primit de printf() poate contine
	//  orice caractere, si doar specificatorii de format vor fi inlocuiti,
	//  in ordinea in care sunt intalniti, cu valorile variabilelor din
	//  lista care urmeaza.
	printf("%e %f %g\n", a, b, c);
	
	// Nu uitati sa intoarceti valoarea "0" la iesirea din functia main()!
	return 0;
}

