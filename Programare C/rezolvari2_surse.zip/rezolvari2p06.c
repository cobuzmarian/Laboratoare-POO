/*
 * Problema 6
 */

// Pentru a avea functiile scanf() si printf():
# include <stdio.h>

int main()
{
	// a, b si c - laturile triunghiului
	int a, b, c;

	// asq, bsq si csq - patratele acestor laturi
	int asq, bsq, csq;

	// Ipoteze despre triunghi: (0 = fals) si (1 = adevarat)
	//  La inceput le vom presupune pe toate false
	int drept = 0, isoscel = 0, echilateral = 0;

	scanf("%d%d%d", &a, &b, &c);

	// Verificam ca cele trei numere formeaza intr-adevar, un triunghi
	if (a > b + c || b > a + c || c > a + b) {

		// Daca NU, atunci termina programul!
		return 0; 

	} else {

		// Verificam prin teorema lui Pitagora daca exista un unghi
		//  drept in triunghi.
		asq = a * a;
		bsq = b * b;
		csq = c * c;
		if (asq + bsq == csq || asq + csq == bsq || bsq + csq == asq)
			drept = 1;

		// Verificam daca triunghiul este echilateral (evident, posibil
		//  doar daca nu este deja dreptunghic)
		if (drept != 1 && (a == b && b == c))
			echilateral = 1;
		// Observatie: operatorul logic SI (&&) isi evalueaza operanzii
		//  de la stanga la dreapta, iar daca o conditie este false,
		//  restul de operanzi nu se mai evalueaza (deja stim ca
		//  rezultatul va fi fals)

		// Verificam daca triunghiul este isoscel (evident, doar daca nu
		//  este deja echilateral)
		if (echilateral != 1 && (a == b || b == c || a == c))
		        isoscel = 1;

		// Afisarea concluziilor
		if (drept == 1) {
			printf ("dreptunghic\n"); 
		} else if (echilateral == 1) {
			printf ("echilateral\n");
		} else if (isoscel == 1) {
			printf ("isoscel\n");
		} else {
			printf ("oarecare\n"); 
		}
	}

	return 0;
}

