/*
 * Problema 8
 */

// Pentru a avea functiile scanf() si printf()
#include <stdio.h>

int main()
{
	int a, b, c, aux;

	scanf("%d%d%d", &a, &b, &c);

	// Vom sorta cele trei numere prin interschimbari. Intai urmarim sa
	//  aducem in variabila "a" minimul dintre cele trei numere. 
	if (a>b) {
		aux = a;
		a = b;
		b = aux;
	}
	if (a>c) {
		aux = a;
		a = c;
		c = aux;
	}

	// In acest moment, in "a" avem valoarea minima. Verificam acum ca si
	//  "b" si "c" sa fie in ordinea corecta!
	if (b>c) {
		aux = b;
		b = c;
		c = aux;
	}

	// Observatie! Metoda de sortare folosita mai sus este de fapt o
	//  defasurare pas cu pas a algoritmului de sortare "Bubble Sort".
	//  Pentru mai multe detalii despre aceasta metoda de sortare, puteti
	//  verifica, de exemplu pagina algoritmului de pe wikipedia:
	//
	//      http://en.wikipedia.org/wiki/Bubble_sort
	
	// Afisam numerele in ordine:
	printf("Numerele sortate: %d, %d, %d\n", a, b, c);

	// Nu uitati sa intoarceti valoarea 0 in main()!
	return 0;
}


