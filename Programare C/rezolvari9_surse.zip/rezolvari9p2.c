/*
 * Problema 2
 *
 */

#include <stdio.h>
#include <time.h>

int main()
{
	time_t t1;
	struct tm *t2;
	time(&t1);
	t2 = localtime(&t1);
	printf("%s%s", ctime(&t1), asctime(t2));
	return 0;
}
