/*
 * Problema 2
 *
 */

#include <stdio.h>
#include <stdlib.h>

#define MAXN 1000

int comp(const void *a, const void *b)
{
	return *(int*)a - *(int*)b; // cast la pointer la intreg mai intai
	// apoi accesam valoarea si returnam rezultatul
}

int main()
{
	int v[MAXN], n, i, x, *poz;
	printf("n = ");
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		//printf("v[%d] = ", i);
		scanf("%d", &v[i]);
	}
	qsort(v, n, sizeof(int), comp);
	for (i = 0; i < n; i++)
		printf("%d ", v[i]);
	printf("\n");
	printf("x = ");
	scanf("%d", &x);
	poz = (int*)bsearch(&x, v, n, sizeof(int), comp);
	printf("Pozitia pe care se afla %d: %d\n", x, poz - v);
	return 0;
}
