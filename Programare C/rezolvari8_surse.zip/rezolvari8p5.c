/*
 * Problema 5
 *
 */

#include<stdlib.h>
#include<stdio.h>
#include<string.h>

int main()
{
	int n, i;
	char (*cuvinte_u)[20] = NULL, (*cuvinte)[20]; // un pointer la un sir de 20 caractere
	int *aparitii;
	scanf("%d\n", &n);
	cuvinte = (char (*)[20]) malloc(n * sizeof(char[20]));

	i = 0;
	while (i < n) {
		scanf("%s", cuvinte[i]);
		i++;
	}

	int dim = 4, unice = 0, k;
	cuvinte_u = (char (*)[20]) malloc(dim * sizeof(char[20]));
	aparitii = (int *) malloc(dim * sizeof(int));

	for (i = 0; i < n; i++) {
		int found = 0;		// variabila care va indica daca am gasit cuvantul in vectorul de aparitii unice

		for (k = 0; k < unice; k++) {
			if (strcmp(cuvinte_u[k], cuvinte[i]) == 0) {
				aparitii[k]++;
				found = 1;
			}
		}

		if (found != 1)	{	//in cazul in care vucantul nu a fost gasit in vectorul de valori unice
			if (unice >= dim) {	//in cazul in care dimensiunea vectorului unic nu a ajuns la limita
				dim *= 2;
				aparitii = (int *) realloc(aparitii, dim * sizeof(int));
				cuvinte_u = (char (*)[20]) realloc(cuvinte_u, dim * sizeof(char[20]));
			}

			strcpy(cuvinte_u[unice], cuvinte[i]);
			aparitii[unice] = 1;
			unice++;
		}
	}
	for (i = 0; i < unice; i++)	{ //afisarea rezultatelor
		printf("%s %d\n", cuvinte_u[i], aparitii[i]);
	}
	//dealocare de memorie
	free(aparitii);
	free(cuvinte_u);
	free(cuvinte);
	return 0;
}
