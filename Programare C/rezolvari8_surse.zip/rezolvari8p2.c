/*
 * Problema 2
 *
 */

#include<stdio.h>
#include<stdlib.h>
#include<string.h>


char *my_strdup(char *s)
{
	char *p = (char *) malloc(strlen(s) + 1);
	strcpy(p, s);
	return p;
}

int main()
{
	char buf[512];
	char *p;
	scanf("%s", buf);
	p = my_strdup(buf);
	printf("%s", p);
	return 0;
}
