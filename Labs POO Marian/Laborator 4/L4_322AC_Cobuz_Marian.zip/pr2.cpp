#include<iostream>
#include<vector>
using namespace std;

class IntSet {
	private:
		int n;
		vector<int>v;
	public:
		IntSet() {
			n = 0;
			vector<int>v;
			
		}
		IntSet(int dim){
			
			n = dim;
			v.resize(dim);

		}
		IntSet contains(int x) {
			for(int i = 0; i < this->n; i++) {
				if(v[i] == x) {
					return 1;
				}
			}
			return 0;
		}
		IntSet add(int x) {
			for(int i = 0; i < this->n; i++) {
				if(v[i] == x) {
					cout << " Elementul este continut deja!" <<endl;
					return 0;
				}
			}
			v.push_back(x);
		}
		IntSet remove(int x) {
			int aux;
			for(int i = 0; i < this->n; i++) {
				if(v[i] != x) {
					cout << "Vectorul nu contine acest element!" <<endl;
					return 0;
				}
				else {
					aux = i;
				}
			}
			for(int i = aux - 1; i < this->n - 1; i++) {
				v[i] = v[i+1];
			}
		}
		IntSet toString() {
			for(int i = 0; i < this->n; i++) {
				cout << v[i] << " " ;
			}
			cout << endl;
		}
		
};

int main() {

	IntSet a(1);
	a.add(2);
	//a.toString();
	a.add(4);
	a.add(5);
	a.add(2);
	cout<<"ha";
	a.remove(6);
	a.toString();
	a.remove(2);
	a.add(4);
	a.toString();
	return 0;
}
